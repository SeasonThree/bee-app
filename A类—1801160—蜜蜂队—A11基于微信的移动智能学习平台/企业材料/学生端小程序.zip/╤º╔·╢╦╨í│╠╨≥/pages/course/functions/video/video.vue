<template>
	<view>
		<view class="start-video">
			<text>孙小红</text>
		</view>
		<view class="start-video" style="left: 10upx;width: 40upx;">
		</view>
		<image src="../../../../static/images/video.jpg" style="width: 100%;height: 1200upx;"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.start-video{
		float: left;
		position: absolute;
		height: 70upx;
		width: 130upx;
		background: black;
		left: 140upx;
		color: white;
		display: flex;
		align-items: center;
		justify-content: center;
		
	}
</style>
