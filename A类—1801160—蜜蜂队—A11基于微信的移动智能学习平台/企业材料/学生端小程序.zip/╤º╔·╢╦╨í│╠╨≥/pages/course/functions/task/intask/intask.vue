<template>
	<view class="intask-content">
		<view style="height:80upx;width:100%;">
			<text style='font-size:42upx;float:left;margin:14upx 0upx 0upx 36upx;' >1.1 &nbsp;&nbsp;第一课时</text>
		</view>	
		<view class='intask-top'>
			<view v-bind:class="{ on : current1, off: current2}" @tap="swich1" >1.视频</view>
			<view v-bind:class="{ intop :current1, on:current2}"  @tap="swich2" >2.章节测验</view>
		</view>
		<swiper  class='intask-swiper'  :current="currentTab" @change="bindchange">
			<swiper-item>
				<view style='height:70upx;width:100%;position:relative;float:left;'>
					<icon class="iconfont icon-yuandian yuandian1" >&#xef03;</icon>
					<text style='float:left;font-size:30upx;margin-top:20upx;'>任务点已完成</text>
				</view>
					<video  style='position:relative;left:50upx;' src="http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400" controls></video>
				<view style='height:70upx;width:100%;position:relative;float:left;'>
					<icon class="iconfont icon-yuandian yuandian1" >&#xef03;</icon>
					<text style='float:left;font-size:30upx;margin-top:20upx;'>任务点已完成</text>
				</view>
				<view style="width: 90%;float: left;margin: 0upx 50upx;">
					<image src="/static/images/service.jpg" style="width: 90%;height: 130upx;"></image>
				</view>
			</swiper-item>
			<swiper-item>
			<view style='height:800upx;' :style="{display:activeDisplay}">
			  <view style='height:70upx;width:100%;position:relative;float:left;background-color:white;'>
			    <icon class="iconfont icon-yuandian yuandian1" >&#xef03;</icon>
			    <text style='float:left;font-size:30upx;margin-top:20upx;'>任务点已完成</text>
			  </view>
			  <view style='height:230upx;background-color:rgb(250, 250, 250);'>
			    <text style='margin:30upx 0upx 0upx 50upx;float:left;'>第一课时</text>
			    <text style='float:left;position:relative;top:90upx;left:-134upx;font-size:30upx;color:green'>已完成</text> 
			    <image src='/static/images/zhangjieceyan.jpg' style='height:90upx;width:90upx;float:right'></image>
			  </view>
				<view style="width: 100%;height: 500upx;background: rgb(250, 250, 250);margin-top: 30upx;">
					<view style="width: 100%;height: 150upx;">
						<text style="float: left;margin: 30upx 50upx;font-size: 40upx;">1.[单选题] 1 + 1 = _____ ?</text>
					</view>
						<block v-for="(item , index) in firstItems" :key="index">
							<view style="width: 100%;height: 87upx;">
								<text style="float: left;margin: 15upx 0upx 0upx 65upx;font-size: 40upx;">{{item.name}}</text>
							</view>
						</block>
						<view style="width: 100%;height: 80upx;font-size: 40upx;border-top: 1px solid #E9E9E9;background:rgb(250, 250, 250);">
							<text style="float: left;margin: 15upx 0upx 0upx 65upx;">正确答案：A</text>
							<text style="float: right;margin: 15upx 65upx 0upx 0upx;">X</text>
						</view>
					<view style="width: 100%;height: 500upx;background: rgb(250, 250, 250);margin-top: 30upx;">
						<view style="width: 100%;height: 150upx;">
							<text style="float: left;margin: 30upx 50upx;font-size: 40upx;">1.[单选题] 2 + 2 = _____ ?</text>
						</view>
						<block v-for="(item, index) in items" :key="index">
							<view style="width: 100%;height: 87upx;">
								<text style="float: left;margin: 15upx 0upx 0upx 65upx;font-size: 40upx;">{{item.name}}</text>
							</view>
						</block>
					</view>
					<view style="width: 100%;height: 80upx;font-size: 40upx;border-top: 1px solid #E9E9E9;background:rgb(250, 250, 250);">
						<text style="float: left;margin: 15upx 0upx 0upx 65upx;">正确答案：D</text>
						<text style="float: right;margin: 15upx 65upx 0upx 0upx;">√</text>
					</view>
				</view>
			</view>	
				
      <view style='height:800upx;' :style="{display:anotherDisplay}">
        <view style='height:70upx;width:100%;position:relative;float:left;background-color:white;'>
          <icon class="iconfont icon-yuandian yuandian2" >&#xef03;</icon>
          <text style='float:left;font-size:30upx;margin-top:20upx;'>任务点</text>
        </view>
        <view style='height:230upx;background-color:rgb(250, 250, 250);'>
          <text style='margin:30upx 0upx 0upx 50upx;float:left;'>第一课时</text>
          <text style='float:left;position:relative;top:90upx;left:-134upx;font-size:30upx;color:red'>未完成                </text> 
          <image src='/static/images/zhangjieceyan.jpg' style='height:90upx;width:90upx;float:right'></image>
        </view>
				<view style="width: 100%;height: 500upx;background: rgb(250, 250, 250);margin-top: 30upx;">
					<view style="width: 100%;height: 150upx;">
						<text style="float: left;margin: 30upx 50upx;font-size: 40upx;">1.[单选题] 1 + 1 = _____ ?</text>
					</view>
					<radio-group>
						<block v-for="(item , index) in firstItems" :key="index">
							<view style="width: 100%;height: 87upx;">
								<label class="radio">
									<radio value="item.value" style="float: left;margin: 15upx 0upx 0upx 50upx;"/>
								</label>
								<text style="float: left;margin: 15upx;font-size: 40upx;">{{item.name}}</text>
							</view>
						</block>
					</radio-group>
					<view style="width: 100%;height: 500upx;background: rgb(250, 250, 250);margin-top: 30upx;">
						<view style="width: 100%;height: 150upx;">
							<text style="float: left;margin: 30upx 50upx;font-size: 40upx;">1.[单选题] 2 + 2 = _____ ?</text>
						</view>
					<radio-group>
						<block v-for="(item, index) in items" :key="index">
							<view style="width: 100%;height: 87upx;">
								<label class="radio">
									<radio :value="item.value" style="float: left;margin: 15upx 0upx 0upx 50upx;"/>
								</label>
								<text style="float: left;margin: 15upx;font-size: 40upx;">{{item.name}}</text>
							</view>
						</block>
					</radio-group>
					</view>
					<button type="primary" class="intask-button" @tap="newLinkTo">确认提交</button>
				</view>
      </view>
    </swiper-item>
		</swiper>
</view>
</template>

<script>
	export default {
		data() {
			return {
				activeDisplay:"none",
				anotherDisplay:"block",
				current1:true,
				current2:false,
				currentTab:"0",
				firstItems:[
					{
						name:"A.2",
						value:"1"
					},
					{
						name:"B.3",
						value:"2"
					},
					{
						name:"C.1",
						value:"3"
					},
					{
						name:"D.4",
						value:"4"
					}
				],
				items:[
					{
						name:"A.1",
						value:"1"
					},
					{
						name:"B.2",
						value:"2"
					},
					{
						value:"3",
						name:"C.3"
					},
					{
						value:"4",
						name:"D.4"
					}
					]
			};
		},

		methods:{
			newLinkTo:function(){
				var pages = getCurrentPages();  //获取第一张到目前的所有页面
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					activeDisplay:'block',
					anotherDisplay:'none'
				});
				uni.showToast({
					title: ' 提交成功',
					duration: 1500
				});
				this.activeDisplay="block",
				this.anotherDisplay="none"
			},
			swich1:function(e){
				this.current2=false;
				this.currentTab="0"
			},
			swich2:function(e){
				this.current2=true;
				this.currentTab="1"
			},
			bindchange:function(e){
				this.currentTab=e.detail.current;
				if (this.currentTab=='0') {
					this.current2=false;
					this.currentTab="0"
				} else{
					this.current2=true;
					this.currentTab="1"
				}
			}
		}
		
}
</script>

<style>
	
	.intask-button{
		width: 80%;
		position: fixed;
		bottom: 25upx;
		margin: 0upx 10%;
	}
	.intask-content{
		height: 1100upx;
		width: 100%;
	}
	.intask-top{
  height: 100upx;
  width:100%;
}
.intop{
  color:black;
  border-bottom: none;
  font-size:42upx;
  height: 100upx;
  width:50%;
  float: left;
  display: flex;
  align-items: center;
  justify-content: center;
}
.yuandian1{
  font-size: 50upx;
  color: green;
  float: left;
  margin: 6upx 0upx 0upx 40upx;
}
.yuandian2{
  font-size: 50upx;
  color: red;
  float: left;
  margin: 6upx 0upx 0upx 40upx;
}
.intask-swiper{
  height: 1450upx;
  width: 100%;
}
.on{
  color: rgb(133, 153, 55);
  border-bottom: 1px solid rgb(133, 153, 55);
  font-size:42upx;
  height: 100upx;
  width:50%;
  float: left;
  display: flex;
  align-items: center;
  justify-content: center;
}
.off{
  color:black;
  border-bottom: none;
  font-size:42upx;
  height: 100upx;
  width:50%;
  float: left;
  display: flex;
  align-items: center;
  justify-content: center;
}
.item-first{
  background-color: green;
  height: 100px;
}
.icon-PageCopy{
  float: right;
  margin: 10upx 24upx;
  color: red;
}

</style>
