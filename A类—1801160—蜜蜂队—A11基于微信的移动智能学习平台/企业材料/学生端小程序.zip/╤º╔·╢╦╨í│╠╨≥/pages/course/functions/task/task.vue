<template>
	<view>
		<view class="task-container" :style="{display: activeDisplay}">
		  <view class="course-search">
		    <input class='course-seach1' placeholder='搜索'></input>
		    <icon class="iconfont icon-sousuo"></icon>
		  </view>
		  <view class='task-notdo'>
		    <text style='margin:34upx 0upx 0upx 40upx;float:left;'>待完成任务点：</text>
		    <icon class="iconfont icon-shuzi1">无</icon>
		  </view>
		  <view class='task-danyuan'>
		    <icon class="iconfont icon-shuzi2">&#xe624;</icon>
		    <text style='margin-left: 20upx;position:relative;top:-7upx;font-weight:bold;'>第一单元</text>
		  </view>
		  <block v-for="(item, index) in items" :key="index">
			  <view class='task-keshi'>
			    <text style='color:grey;font-size:30upx;margin: 44upx 0upx 0upx 56upx;float:left;'>{{item.littleText}}</text>
			    <icon class="iconfont icon-yuan">&#xe60a;</icon>
			    <text style='position:relative;top:-6upx;margin-left:21upx;'>{{item.heighText}}</text>
			    <icon class="iconfont icon-xiazai">&#xe8c7;</icon>
			  </view>
		  </block>
		  <view class='task-danyuan'>
		    <icon class="iconfont icon-shuzi3" style='font-size:50upx'>&#xe625;</icon>
		    <text style='margin-left: 20upx;position:relative;top:-8upx;font-weight:bold;'>第二单元</text>
		  </view>
		  <block v-for="(item, index) in secondItems" :key="index">
			  <view class='task-keshi'>
			    <text style='color:grey;font-size:30upx;margin: 44upx 0upx 0upx 56upx;float:left;'>{{item.littleText}}</text>
			    <icon class="iconfont icon-yuan">&#xe60a;</icon>
			    <text style='position:relative;top:-6upx;margin-left:21upx;'>{{item.heighText}}</text>
			    <icon class="iconfont icon-xiazai">&#xe8c7;</icon>
			  </view>
		  </block>
		</view>
		
		<view class="task-container" :style="{display: anotherDisplay}">
  <view class="course-search">
    <input class='course-seach1' placeholder='搜索'></input>
    <icon class="iconfont icon-sousuo"></icon>
  </view>
  <view class='task-notdo'>
    <text style='margin:34upx 0upx 0upx 40upx;float:left;'>待完成任务点：</text>
    <icon class="iconfont icon-shuzi1">&#xe62c;</icon>
  </view>
  <view class='task-danyuan'>
    <icon class="iconfont icon-shuzi2">&#xe624;</icon>
    <text style='margin-left: 20upx;position:relative;top:-7upx;font-weight:bold;'>第一单元</text>
  </view>
  <view class='task-keshi' @tap='intaskto'>
    <text style='color:grey;font-size:30upx;margin: 42upx 0upx 0upx 56upx;float:left;'>1.1</text>
    <icon class="iconfont icon-shuzi1 shuzi1">&#xe62c;</icon>
    <text style='position:relative;top:-10upx;margin-left:20upx;' >第一课时</text>
    <icon class="iconfont icon-xiazai">&#xe8c7;</icon>
  </view>
	<block v-for="(item, index) in thirdItems" :key="index">
	  <view class='task-keshi'>
	    <text style='color:grey;font-size:30upx;margin: 44upx 0upx 0upx 56upx;float:left;'>{{item.littleText}}</text>
	    <icon class="iconfont icon-yuan">&#xe60a;</icon>
	    <text style='position:relative;top:-6upx;margin-left:21upx;'>{{item.heighText}}</text>
	    <icon class="iconfont icon-xiazai">&#xe8c7;</icon>
	  </view>
	</block>
  <view class='task-danyuan'>
    <icon class="iconfont icon-shuzi3" style='font-size:50upx'>&#xe625;</icon>
    <text style='margin-left: 20upx;position:relative;top:-8upx;font-weight:bold;'>第二单元</text>
  </view>
	<block v-for="(item, index) in secondItems" :key="index">
	  <view class='task-keshi'>
	    <text style='color:grey;font-size:30upx;margin: 44upx 0upx 0upx 56upx;float:left;'>{{item.littleText}}</text>
	    <icon class="iconfont icon-yuan">&#xe60a;</icon>
	    <text style='position:relative;top:-6upx;margin-left:21upx;'>{{item.heighText}}</text>
	    <icon class="iconfont icon-xiazai">&#xe8c7;</icon>
	  </view>
	</block>
</view>
	</view>
	
</template>

<script>
	export default {
		data() {
			return {
				activeDisplay:"none",
				anotherDisplay:"block",
				items:[
					{
						littleText:"1.1",
						heighText:"第一课时"
					},
					{
						littleText:"1.2",
						heighText:"第二课时"
					},
					{
						littleText:"1.3",
						heighText:"第三课时"
					},
					{
						littleText:"1.4",
						heighText:"第四课时"
					},
					{
						littleText:"1.5",
						heighText:"第五课时"
					}
				],
				secondItems:[
					{
						littleText:"2.1",
						heighText:"第一课时"
					},
					{
						littleText:"2.2",
						heighText:"第二课时"
					},
					{
						littleText:"2.3",
						heighText:"第三课时"
					},
					{
						littleText:"2.4",
						heighText:"第四课时"
					},
					{
						littleText:"2.5",
						heighText:"第五课时"
					}
				],
				thirdItems:[
					{
						littleText:"1.2",
						heighText:"第二课时"
					},
					{
						littleText:"1.3",
						heighText:"第三课时"
					},
					{
						littleText:"1.4",
						heighText:"第四课时"
					},
					{
						littleText:"1.5",
						heighText:"第五课时"
					}
				],
			};
		},
		onShow() {
			let pages = getCurrentPages();
			let currPage = pages[pages.length - 1];
			if(currPage.data.activeDisplay==undefined)
			{
				activeDisplay:"none"
			}
			if(currPage.data.anotherDisplay==undefined)
			{
				anotherDisplay:"block"
			}
			else
			{
				this.activeDisplay=currPage.data.activeDisplay,
				this.anotherDisplay=currPage.data.anotherDisplay
			}
			
		},
		methods:{
			intaskto:function(){
				uni.navigateTo({
					url:"/pages/course/functions/task/intask/intask"
				})
			}
		}
	}
</script>

<style>
			.task-container{
			height: 1400upx;
			width: 100%;
		}
		.course-search{
			height: 90upx;
			width: 100%;
			margin: auto;
			background-color: white;
		}
		.course-search .icon-sousuo{
			position: relative;
			left: 290upx;
			top: -62upx;
			z-index: 1;
		}
		.course-seach1{
			z-index: 0;
			height: 60upx;
			width: 600upx;
			background-color: rgb(245, 246, 248);
			margin:auto;
			position: relative;
			top: 10upx;
			font-size:25upx; 
			border-radius: 40upx;
			text-align: center;
		}
		.task-notdo{
			height: 100upx;
			width: 100%;
			background-color: rgb(234, 233, 239);
		}
		.icon-shuzi1{
			margin-top: 24upx;
			font-size: 50upx;
			color: rgb(252, 159, 0);
		}
		.task-danyuan{
			height: 140upx;
			width: 100%;
			background-color: rgb(240, 240, 240);
		}
		.icon-shuzi2, .icon-shuzi3{
			font-size: 40upx;
			margin: 36upx 0upx 0upx 50upx;
			font-size: 50upx;
			color: grey;
		}
		.task-keshi{
			height: 120upx;
			width: 100%;
			background: white;
			border-bottom: 1px solid rgb(226, 226, 226);
		}
		.shuzi1{
			margin: 30upx 0upx 0upx 22upx;
		}
		.icon-yuan{
			margin: 30upx 4upx 0upx 24upx;
			font-size: 44upx;
			color: rgb(125, 154, 60);
		}
		.icon-xiazai{
			float: right;
			font-size: 56upx;
			margin: 30upx 32upx 0upx 0upx;
			color: rgb(70, 196, 143);
		}
</style>
