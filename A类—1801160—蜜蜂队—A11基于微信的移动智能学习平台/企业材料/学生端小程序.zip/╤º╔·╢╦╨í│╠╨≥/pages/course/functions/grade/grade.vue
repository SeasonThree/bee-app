<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="blue-top" style="position: fixed;top: 0upx;">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view style="height: 150upx;width: 100%;"></view>
		<view style="width: 100%;height: 60upx;">
			<text style="float: left;margin: 14upx 30upx 0upx;font-size: 32upx;color: #999999;">课程时间</text>
		</view>
		<view style="width: 100%;height: 180upx;background: white;color: rgb(106, 106, 106);">
			<view style="width: 100%;height: 50%;">
				<text style="float: left;margin: 24upx 30upx 0upx;">开始时间：2018-9-15 00:00:00</text>
			</view>
			<view style="width: 100%;height: 50%;">
				<text style="float: left;margin: 24upx 30upx 0upx;">结束时间：2019-1-5 23:59:59</text>
			</view>
		</view>
		<view style="width: 100%;height: 60upx;">
			<text style="float: left;margin: 14upx 30upx 0upx;font-size: 32upx;color: #999999;">考试安排</text>
		</view>
		<view style="width: 100%;height: 180upx;background: white;">
			<view style="width: 100%;height: 50%;color: rgb(106, 106, 106);">
				<text style="float: left;margin: 34upx 30upx 0upx;font-size: 40upx;">《高等数学》期末考试</text>
			</view>
			<view style="width: 100%;height: 50%;">
				<text style="float: left;margin: 24upx 42upx 0upx;font-size: 30upx;color: #999999;">2019-1-14 09:00:00——11:00:00</text>
			</view>
		</view>
		<view style="width: 100%;height: 60upx;">
			<text style="float: left;margin: 14upx 30upx 0upx;font-size: 32upx;color: #999999;">考核标准</text>
			<text style="float: right;margin: 14upx 30upx 0upx 0upx;font-size: 32upx;color: red">89.5分</text>
			<text style="float: right;margin: 14upx 0upx  0upx 30upx;font-size: 32upx;color: #999999;">当前得分：</text>
		</view>
		<view style="width: 100%;height: 180upx;background: white;">
			<view style="width: 100%;height: 50%;color: rgb(106, 106, 106);">
				<text style="float: left;margin: 32upx 30upx 0upx;">视频：15%</text>
			</view>
			<view style="width: 100%;height: 50%;font-size:28upx ;color: #999999;">
				<text style="float: left;margin: 10upx 30upx 0upx;">课程视频全部看完得满分，单个视频分值平均分配，满分100分</text>
			</view>
		</view>
		<view style="width: 100%;height: 180upx;background: white;">
			<view style="width: 100%;height: 50%;color: rgb(106, 106, 106);">
				<text style="float: left;margin: 32upx 30upx 0upx;">测验：15%</text>
			</view>
			<view style="width: 100%;height: 50%;font-size:28upx ;color: #999999;">
				<text style="float: left;margin: 10upx 30upx 0upx;">学生接收到的所有测验任务点平均分配，未做测验按“零”分计算</text>
			</view>
		</view>
		<view style="width: 100%;height: 150upx;background: white;">
			<view style="width: 100%;height: 90upx;color: rgb(106, 106, 106);">
				<text style="float: left;margin: 32upx 30upx 0upx;">考勤：10%</text>
			</view>
			<view style="width: 100%;height: 60upx;font-size:28upx ;color: #999999;">
				<text style="float: left;margin: 10upx 30upx 0upx;">学生的考勤分数按考勤次数的百分比计算。</text>
			</view>
		</view>
		<view style="width: 100%;height: 180upx;background: white;">
			<view style="width: 100%;height: 50%;color: rgb(106, 106, 106);">
				<text style="float: left;margin: 32upx 30upx 0upx;">考试：60%</text>
			</view>
			<view style="width: 100%;height: 50%;font-size:28upx ;color: #999999;">
				<text style="float: left;margin: 10upx 30upx 0upx;">所有考试的平均分</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			};
		}
	}
</script>

<style>

</style>
