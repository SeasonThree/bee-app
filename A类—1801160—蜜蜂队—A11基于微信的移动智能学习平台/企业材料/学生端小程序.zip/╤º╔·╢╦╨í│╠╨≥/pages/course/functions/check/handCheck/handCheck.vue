<template>
	<view style="width: 100%;height: 1200upx;background: rgb(245, 246, 248);">
		<view class="handCheck-top">
			<text>重绘发起者传达的手势图案完成签到</text>
		</view>
		<view class="uni-padding-wrap uni-common-mt">
			<view>
				<mpvue-gesture-lock :containerWidth="590" :cycleRadius="70" @end="onEnd" :password="password"></mpvue-gesture-lock>
			</view>
			<view class="uni-helllo-text uni-common-mt uni-center handCheck-text">{{text}}</view>
		</view>
	</view>
</template>

<script>
	import mpvueGestureLock from '@/components/mpvueGestureLock';
	export default {
		components: {
		    mpvueGestureLock
		},
		data() {
			return {
				password: [],
				text: '请确定手势'
			};
		},
		methods: {
		    onEnd(data) {
		        if (this.password.length) {
		            if (this.password.join('') === data.join('')) {
		                this.text = '手势设定完成'
		                this.password = []
		            } else {
		                this.text = '两次手势设定不一致'
		                this.password = []
		            }
		        } else {
					var pages = getCurrentPages();  //获取第一张到目前的所有页面
					var currPage = pages[pages.length - 1];  //获取当前页面
					var prevPage = pages[pages.length - 2];	 //获取前一张页面
					prevPage.setData({
						text1:'已签'
					});
		            this.text="签到成功";
		            uni.showToast({
		            	title: ' 签到成功',
		            	duration: 1500
		            });
		            setTimeout(function(){
		            	uni.navigateBack({
		            	delta: 1
		            	});
		            },1500);
		        }
		    }
		}
	}
</script>

<style>
	.handCheck-top{
		float: left;
		width: 100%;
		height: 100upx;
		margin-top: 200upx;
		margin-bottom: 40upx;
		display: flex;
		align-items: center;
		justify-content: center;
		color: rgb(149, 150, 152);
	}
	.handCheck-text{
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 40upx;
	}
</style>
