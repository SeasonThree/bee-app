<template>
	<view>
		<view >
			<image src="/static/images/location.jpg" style="width: 100%;height: 900upx;"></image>
		</view>
		<view style="width: 100%;height: 100upx;display: flex;justify-content: center;align-items: center;margin-top: 50upx;">
			<label class="checkbox" style="font-size: 40upx;color: #9D9D9D;">
				<checkbox value="s1" checked='true' />同意提交位置信息
			</label>
		</view>
		<view style="width: 100%;height: 100upx;display: flex;justify-content: center;align-items: center;">
			<button type="primary" style="background: #007AFF;width: 90%;" @tap="locationTo">签到</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			locationTo:function(){
				var pages = getCurrentPages();  //获取第一张到目前的所有页面
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					text2:'已签'
				});
				uni.showToast({
					title: ' 签到成功',
					duration: 1500
				});
				setTimeout(function(){
					uni.navigateBack({
					delta: 1
					});
				},1500);
			}
		}
		
	}
</script>

<style>

</style>
