<template>
	<view style="background: rgb(245, 246, 248);height: 1208upx;width: 100%;">
		<view style="border-top: 1px solid #E9E9E9;"></view>
		<view style="text-align: center;width: 100%;float: left;margin-top: 200upx;">
			<text style="">请输入数字，手动完成签到</text>
		</view>
		<view style="float: left;margin-top: 40upx;width: 100%;height: 150upx;">
			<input type="text" class="incheck-input"/>
		</view>
		<view style="float: left;margin-top: 40upx;width: 100%;height: 150upx;" @tap="incheckto">
			<button type="warn" style="width: 50%;margin: 0px 25%;">立即签到</button>
		</view>
		<view style="width: 100%;height: 400upx;float: left;">
			<image src="../../../../../static/images/incheck.jpg" style="width: 50%;height: 100%;margin: 20upx 25%;"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			incheckto:function(){
				
				var pages = getCurrentPages();  //获取第一张到目前的所有页面
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					text:'已签'
				});
				uni.showToast({
					title: ' 签到成功',
					duration: 1500
				});
				setTimeout(function(){
					uni.navigateBack({
					delta: 1
					});
				},1500);
				
			}
		}
	}
</script>

<style>
	.incheck-input{
		width: 50%;
		height: 100upx;
		border: 1px solid #808080;
		border-radius: 5px;
		margin: 10px 25%;
		font-size: 25px;
		text-align: center;
	}
</style>
