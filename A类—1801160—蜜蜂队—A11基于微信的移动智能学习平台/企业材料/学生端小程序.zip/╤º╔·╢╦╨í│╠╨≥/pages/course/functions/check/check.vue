<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="blue-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view class="checkButton">
			<button  class="check-button" @tap="Recordto">查看我的考勤记录</button>
		</view>
		
		<view class="all-content">
			<view @tap="checkto" style="height: 25%;width: 100%;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/check.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;color: red;">[数字签到]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-03</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{text}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="codeTo">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/check.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;" >
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;color: red;">[二维码签到]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-02</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{textqr}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:11:11</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="newCheckTo">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/check.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;color: red;">[手势签到]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-01</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{text1}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">21:15:11</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="locationTo">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/check.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;color: red;">[位置签到]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-01</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{text2}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">18:40:11</text>
				</view>
			</view>
		</view>
		<view style="width: 100%;text-align: center;float: left;margin-top: 50upx;font-size: 13px;color: #808080;">
			<text>已经到底啦(*╹▽╹*)</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				text:"未签",
				text1:"未签",
				text2:"未签",
				textqr:"未签"
			};
		},
		onShow() {
			let pages = getCurrentPages();
			let currPage = pages[pages.length - 1];
			if(currPage.data.text==undefined)
			{
				this.text='未签'
			}
			else
				this.text= currPage.data.text
				
			if(currPage.data.text1==undefined)
			{
				this.text1="未签"
			}
			else
				this.text1= currPage.data.text1
				
			if(currPage.data.text2==undefined)
			{
				this.text2="未签"
			}
			else
				this.text2= currPage.data.text2
			if(getApp().gloabalData=="qr"){
				this.textqr="已签"
			}
		},
		methods:{
			
			codeTo:function(){
				getApp().gloabalData='qr'
				uni.scanCode({
					success: function (res) {
					console.log('条码类型：' + res.scanType);
					console.log('条码内容：' + res.result);
					uni.showToast({
						title: '已签到',
						mask: false,
						duration: 1500
					});
					
					
					}
				});
			},
			Recordto:function(){
				uni.navigateTo({
					url:"/pages/course/functions/check/checkRecord/checkRecord"
				})
			},
			checkto:function(){
				if(this.text=="已签")
				{
					uni.showToast({
						title: ' 已签到',
						duration: 1000
					});
				}
				else
				{
					uni.navigateTo({
						url:"/pages/course/functions/check/incheck/incheck"
					});
				}
			},
			newCheckTo:function(){
				if(this.text1=="已签")
				{
					uni.showToast({
						title: ' 已签到',
						duration: 1000
					});
				}
				else
				{
					uni.navigateTo({
						url:"/pages/course/functions/check/handCheck/handCheck"
					});
				}
			},
			locationTo:function(){
				if(this.text2=="已签")
				{
					uni.showToast({
						title: ' 已签到',
						duration: 1000
					});
				}
				else
				{
					uni.navigateTo({
						url:"/pages/course/functions/check/locationCheck/locationCheck"
					})
				}
				
			}
		}
	}
</script>

<style>
	.all-img{
		width: 90upx;
		height: 90upx;
		margin:30upx;
	}
	.check-button{
		font-size: 16px;
		width: 60%;
		float: left;
		margin:4% 20% 0upx 20%;
		background: #007AFF;
		color: white;
	}
	.checkButton{
		height: 150upx;
		width: 100%;
		float: left;
		margin-top: 40upx;
		border-top:1px solid rgb(242, 242, 242);
		border-bottom: 1px solid rgb(242, 242, 242);
		background: white;
	}
	.blue-top{
		height: 150upx;
		width: 100%;
		background: #21B0FF;
		text-align: center;
	}
</style>
