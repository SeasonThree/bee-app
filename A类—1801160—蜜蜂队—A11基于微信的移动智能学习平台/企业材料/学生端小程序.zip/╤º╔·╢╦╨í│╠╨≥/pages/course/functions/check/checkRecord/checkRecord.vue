<template>
	<view style="width: 100%;height: 1208upx;background: rgb(245, 246, 248);">
		<view class="student-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view class="record-top">
			<view style="height: 100%;width: 25%;display: flex;align-items: center;justify-content: center;float: left;font-size: 17px;">
				<text style="color: rgb(139, 195, 75);">出勤：3次</text>
			</view>
			<view style="height: 100%;width: 25%;display: flex;align-items: center;justify-content: center;float: left;font-size: 17px;">
				<text style="color: rgb(230, 48, 55);">缺勤：1次</text>
			</view>
			<view style="height: 100%;width: 25%;display: flex;align-items: center;justify-content: center;float: left;font-size: 17px;">
				<text style="color: rgb(255, 167, 38);">迟到：0次</text>
			</view>
			<view style="height: 100%;width: 25%;display: flex;align-items: center;justify-content: center;float: left;font-size: 17px;">
				<text style="color: rgb(106, 123, 219);">请假：0次</text>
			</view>
		</view>
		<view style="height: 600upx;width: 100%;background: white;">
			<view  style="height: 25%;width: 100%;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="/static/images/check.jpg" class="check-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">2018-12-03</text>
					<text style="float: right;font-size: 22px;position: relative;top: 50upx;left: -30upx;color: rgb(139, 195, 75);">出勤</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 25upx;float: left;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" >
				<view style="height: 100%;width:150upx;float: left;">
					<image src="/static/images/check.jpg" class="check-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">2018-12-02</text>
					<text style="float: right;font-size: 22px;position: relative;top: 50upx;left: -30upx;color: rgb(139, 195, 75);">出勤</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 25upx;float: left;font-size: 13px;color: #808080;">20:11:11</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="/static/images/check.jpg" class="check-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">2018-12-01</text>
					<text style="float: right;font-size: 22px;position: relative;top: 50upx;left: -30upx;color: red;">缺勤</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 25upx;float: left;font-size: 13px;color: #808080;">21:15:11</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" >
				<view style="height: 100%;width:150upx;float: left;">
					<image src="/static/images/check.jpg" class="check-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">2018-12-01</text>
					<text style="float: right;font-size: 22px;position: relative;top: 50upx;left: -30upx;color: rgb(139, 195, 75);">出勤</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 25upx;float: left;font-size: 13px;color: #808080;">18:40:11</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.check-img{
		width: 90upx;
		height: 90upx;
		margin:30upx;
	}
	.record-top{
		height: 180upx;
		width: 100%;
		background: white;
	}
	.student-top{
		height: 150upx;
		width: 100%;
		background: #21B0FF;
		text-align: center;
	}
</style>
