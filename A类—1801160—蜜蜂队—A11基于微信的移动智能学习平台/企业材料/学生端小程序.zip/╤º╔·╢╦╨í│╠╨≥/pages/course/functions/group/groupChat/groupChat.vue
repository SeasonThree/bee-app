<template>
	<view style="width: 100%;height: 1200upx;background: rgb(235, 235, 235);">
		<view class="chat-expands" @tap="chatTo">
			<icon class="iconfont" style="font-size: 42upx;">&#xe63c;</icon>
		</view>
		<view class="group-chat">
			<icon class="iconfont icon-yuyin">&#xe618;</icon>
			<input type="text" class="group-input" />
			<icon class="iconfont icon-yuyin" style="margin-left:20upx;">&#xe631;</icon>
			<icon class="iconfont" style="font-size: 66upx;margin: 0upx 20upx;">&#xe61a;</icon>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			chatTo:function(){
				uni.navigateTo({
					url:"/pages/course/functions/group/groupChat/chatMessage/chatMessage"
				})
			}
		}
	}
</script>

<style>
	.chat-expands{
		width: 90upx;
		height: 90upx;
		background: white;
		border-radius: 50upx;
		position: fixed;
		top: 200upx;
		right: 0upx;
		display: flex;
		align-items: center;
		justify-content: center;
		border: 1px soild #CCCCCC;
	}
	.group-input{
		background: white;
		height: 80upx;
		width: 480upx;
		border-radius: 5upx;
		font-size: 40upx;
		padding-left: 10upx;
	}
	.icon-yuyin{
		font-size: 60upx;
	}
	.group-chat{
		height: 130upx;
		width: 100%;
		position: fixed;
		bottom: 0px;
		background: rgb(244, 244, 246);
		display: flex;
		justify-content: center;
		align-items: center;
		border: 1px solid #CCCCCC;
	}
</style>
