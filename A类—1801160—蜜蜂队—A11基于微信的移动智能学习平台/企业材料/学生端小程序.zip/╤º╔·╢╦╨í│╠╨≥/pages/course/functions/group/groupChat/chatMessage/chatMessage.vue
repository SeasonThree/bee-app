<template>
	<view style="width: 100%;height: 1200upx;background: rgb(235, 235, 235);">
		<view style="height: 120upx;width: 100%;float: left;background: white;border-top: 1px solid #E9E9E9;">
			<view class="all-search" style="margin-top: 15upx;">
			  <input class='all-seach1' placeholder='搜索' style="background: rgb(245, 246, 248);"></input>
			  <icon class="iconfont icon-sousuo">&#xe61c;</icon>
			</view>
		</view>
		<view class="message-second">
			<view style="height: 50%;width: 100%; border-bottom: 1px solid #E9E9E9;" >
				<text style="font-size: 38upx;float: left;margin: 28upx 30upx 0upx;color: #808080;">课程名称:</text>
				<text style="float: left;margin: 32upx 20upx 0upx;">高等数学</text>
			</view>
			<view style="height: 50%;width: 100%;">
				<text style="font-size: 38upx;float: left;margin: 28upx 30upx 0upx 110upx ;color: #808080;">教师:</text>
				<text style="float: left;margin: 32upx 20upx 0upx;">XXX老师</text>
			</view>
		</view>
		<view class="message-third">
			<view style="height: 25%;width: 100%; border-bottom: 1px solid #E9E9E9;" >
				<text style="font-size: 38upx;float: left;margin: 28upx 30upx 0upx;">小组邀请码</text>
				<text style="float: right;margin: 32upx 30upx 0upx;color: #969896;" class="iconfont" @tap="showMiddlePopup">uf17124 &#xe61b;</text>
			</view>
			<view style="height: 25%;width: 100%; border-bottom: 1px solid #E9E9E9;" >
				<text style="font-size: 38upx;float: left;margin: 28upx 30upx 0upx;">搜索聊天记录</text>
				<text style="float: right;margin: 28upx 30upx 0upx;color: #969896;font-size: 40upx;" class="iconfont">&#xe630;</text>
			</view>
			<view style="height: 25%;width: 100%; border-bottom: 1px solid #E9E9E9;" >
				<text style="font-size: 38upx;float: left;margin: 28upx 30upx 0upx;">清除聊天记录</text>
			</view>
			<view style="height: 25%;width: 100%; border-bottom: 1px solid #E9E9E9;" >
				<image src="/static/images/group.png" class="chat-img" ></image>
				<text style="font-size: 38upx;float: left;margin: 25upx 30upx 0upx;">上传小组图标</text>
			</view>
		</view>
		<view style="float: left;height: 50upx;width: 100%;margin-top: 15upx;">
			<text style="font-size: 32upx;margin-left: 30upx;">成员（4）</text>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
			<view style="float: left;">
				<image src="/static/images/jianshang.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">楚若黎</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 60%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082312</text>
				</view>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
			<view style="float: left;">
				<image src="/static/images/mama.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">顾润之</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 60%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082313</text>
				</view>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
			<view style="float: left;">
				<image src="/static/images/lishi.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">楚秋然</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 60%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082314</text>
				</view>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
			<view style="float: left;">
				<image src="/static/images/xinli.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">愧泽</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 50%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082315</text>
			</view>
		</view>
		<uni-popup :show="showPopupMiddle" :type="popType" v-on:hidePopup="hidePopup">
			<view class="uni-center" style="font-size:0;">
				<image style="width:300upx;height:300upx;" mode="widthFix" src="/static/images/QR_code.jpg" />
			</view>
			<view >
				<text>uf17124</text>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup.vue';
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				popType: 'middle',
				showPopupMiddle: false
			};
		},
		methods:{
			//统一的关闭popup方法
			hidePopup: function() {
				this.showPopupMiddle = false;
			},
			//展示居中 popup
			showMiddlePopup: function() {
				this.hidePopup();
				this.popType = 'middle';
				this.showPopupMiddle = true;
			}
		}
	}
</script>

<style>
	.icon-yezi{
	  color: rgb(135, 214, 16);
	}
	.student-teacher{
		height: 100upx;
		width: 100upx;
		margin: 20upx 20upx 0upx 30upx;
		border-radius: 10upx;
	}
	.chat-img{
		height: 70upx;
		width: 70upx;
		float: right;
		margin: 12upx 30upx 0upx;
	}
	.message-third{
		height: 400upx;
		width: 100%;
		background: white;
		border: 1px solid #E9E9E9;
		margin-top: 40upx;
		float: left;
	}
	.message-second{
		height: 200upx;
		width: 100%;
		background: white;
		border: 1px solid #E9E9E9;
		margin-top: 40upx;
		float: left;
	}
</style>
