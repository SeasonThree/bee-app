<template>
	<view style="width: 100%;height: 1200upx;background: rgb(245, 246, 248);">
		<view style="height: 80upx;width: 100%;margin: 30upx 0upx 40upx;float: left;">
			<view class="all-search">
			  <input class='all-seach1' placeholder='搜索'></input>
			  <icon class="iconfont icon-sousuo">&#xe61c;</icon>
			</view>
		</view>
		<view class="group-content">
			<view style="width: 100%;height: 25%;display: flex;flex-direction: row;border-bottom: 1px solid #E9E9E9;" @tap="groupTo">
				<view style="width: 18%;height: 100%;justify-content: center;align-items: center;display: flex;">
					<image src="../../../../static/images/jianshang.jpg" class="group-img"></image>
				</view>
				<view style="width: 62%;height: 100%;">
					<text style="margin-top: 45upx;float: left;font-size: 18px;color: red;">班级讨论组</text>
				</view>
				<view style="width: 20%;height: 100%;">
					<icon class="iconfont icon-jiantou">&#xe630;</icon>
				</view>
			</view>
			<view style="width: 100%;height: 25%;display: flex;flex-direction: row;border-bottom: 1px solid #E9E9E9;">
				<view style="width: 18%;height: 100%;justify-content: center;align-items: center;display: flex;">
					<image src="../../../../static/images/life.jpg" class="group-img"></image>
				</view>
				<view style="width: 62%;height: 100%;">
					<text style="margin-top: 45upx;float: left;font-size: 18px;">蜜蜂</text>
				</view>
				<view style="width: 20%;height: 100%;">
					<icon class="iconfont icon-jiantou">&#xe630;</icon>
				</view>
			</view>
			<view style="width: 100%;height: 25%;display: flex;flex-direction: row;border-bottom: 1px solid #E9E9E9;">
				<view style="width: 18%;height: 100%;justify-content: center;align-items: center;display: flex;">
					<image src="../../../../static/images/chadao.jpg" class="group-img"></image>
				</view>
				<view style="width: 62%;height: 100%;">
					<text style="margin-top: 45upx;float: left;font-size: 18px;">高数作业小组</text>
				</view>
				<view style="width: 20%;height: 100%;">
					<icon class="iconfont icon-jiantou">&#xe630;</icon>
				</view>
			</view>
			<view style="width: 100%;height: 25%;display: flex;flex-direction: row;border-bottom: 1px solid #E9E9E9;">
				<view style="width: 18%;height: 100%;justify-content: center;align-items: center;display: flex;">
					<image src="../../../../static/images/xinli.jpg" class="group-img"></image>
				</view>
				<view style="width: 62%;height: 100%;">
					<text style="margin-top: 45upx;float: left;font-size: 18px;">新的小组</text>
				</view>
				<view style="width: 20%;height: 100%;">
					<icon class="iconfont icon-jiantou">&#xe630;</icon>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			groupTo:function(){
				uni.navigateTo({
					url:"/pages/course/functions/group/groupChat/groupChat"
				})
			}
		}
	}
</script>

<style>
	.icon-jiantou{
	  float: right;
	  font-size: 50rpx;
	  margin:40rpx 25rpx 0rpx 0rpx;
	}
	.group-img{
		width: 100upx;
		height: 100upx;
		border-radius: 50upx;
		
	}
	.group-content{
		height: 550upx;
		width: 100%;
		float: left;
		background: white;
	}
</style>
