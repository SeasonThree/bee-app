<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="inquiz-top">
			<text>我的排名：1</text>
		</view>
		<view class="inquiz-content">
			<view style="height: 25%;width: 100%;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view class="inquiz-first">
					<text style="color: #999999">1</text>
				</view>
				<view style="width: 16%;height: 100%;float: left;">
					<image src="../../../../../static/images/me.jpg" class="inquiz-img"></image>
				</view>
				<view style="width: 49%;height: 100%;float: left;">
					<text style="float: left;margin-top: 50upx;">顾润之</text>
				</view>
				<view style="width: 21%;height: 100%;float: left;display: flex;align-items: center;justify-content: center;">
					<text style="font-size: 15px;color: #999999">7秒</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" >
				<view class="inquiz-first">
					<text style="color: #999999">2</text>
				</view>
				<view style="width: 16%;height: 100%;float: left;">
					<image src="../../../../../static/images/jianshang.jpg" class="inquiz-img"></image>
				</view>
				<view style="width: 49%;height: 100%;float: left;">
					<text style="float: left;margin-top: 50upx;">楚若黎</text>
				</view>
				<view style="width: 21%;height: 100%;float: left;display: flex;align-items: center;justify-content: center;">
					<text style="font-size: 15px;color: #999999">14秒</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" >
				<view class="inquiz-first">
					<text style="color: #999999">3</text>
				</view>
				<view style="width: 16%;height: 100%;float: left;">
					<image src="../../../../../static/images/lishi.jpg" class="inquiz-img"></image>
				</view>
				<view style="width: 49%;height: 100%;float: left;">
					<text style="float: left;margin-top: 50upx;">楚秋然</text>
				</view>
				<view style="width: 21%;height: 100%;float: left;display: flex;align-items: center;justify-content: center;">
					<text style="font-size: 15px;color: #999999">1分钟</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" >
				<view class="inquiz-first">
					<text style="color: #999999">4</text>
				</view>
				<view style="width: 16%;height: 100%;float: left;">
					<image src="../../../../../static/images/xinli.jpg" class="inquiz-img"></image>
				</view>
				<view style="width: 49%;height: 100%;float: left;">
					<text style="float: left;margin-top: 50upx;">愧泽</text>
				</view>
				<view style="width: 21%;height: 100%;float: left;display: flex;align-items: center;justify-content: center;">
					<text style="font-size: 15px;color: #999999">1分20秒</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.inquiz-img{
		width: 90upx;
		height: 90upx;
		margin:22upx 0upx 0upx 8upx;
		border-radius: 7upx;
		border: 1px solid #E9E9E9;
	}
	.inquiz-first{
		width: 14%;
		height: 100%;
		float: left;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.inquiz-content{
		height: 550upx;
		width: 100%;
		float: left;
		background: white;
	}
	.inquiz-top text{
		font-size: 15px;
		float: left;
		margin: 22upx 35upx;
	}
	.inquiz-top{
		height: 80upx;
		width: 100%;
	}
</style>
