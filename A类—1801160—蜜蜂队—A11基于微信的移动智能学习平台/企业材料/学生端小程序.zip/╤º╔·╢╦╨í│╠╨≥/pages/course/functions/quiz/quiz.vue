<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="blue-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		
		<view class="all-content">
			<view @tap="quizTo" style="height: 25%;width: 100%;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/quiz.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">[抢答]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-03</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已抢</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="choiceTo" >
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/choice.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">[选人]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-02</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">选中：顾润之</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:11:11</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="haschoiced">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/choiced.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">[选人]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-01</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">选中：楚若黎</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">21:15:11</text>
				</view>
			</view>
			<view style="height: 25%;width: 100%;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="hasquized">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/quized.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">[抢答]</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-12-01</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已抢</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">18:40:11</text>
				</view>
			</view>
		</view>
		<view style="width: 100%;text-align: center;float: left;margin-top: 50upx;font-size: 13px;color: #808080;">
			<text>已经到底啦(*╹▽╹*)</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			quizTo:function(){
				uni.navigateTo({
					url:"/pages/course/functions/quiz/inquiz/inquiz"
				})
			},
			choiceTo:function(){
				uni.navigateTo({
					url:"/pages/course/functions/quiz/inchoice/inchoice"
				})
			},
			haschoiced:function(){
				uni.showToast({
					title: '选人已过期',
					image:"/static/images/失败.png",
					icon:"none",
					duration: 1000
				});
			},
			hasquized:function(){
				uni.showToast({
					title: '抢答已过期',
					image:"/static/images/失败.png",
					icon:"none",
					duration: 1000
				})
				
			}
		}
	}
</script>

<style>
</style>
