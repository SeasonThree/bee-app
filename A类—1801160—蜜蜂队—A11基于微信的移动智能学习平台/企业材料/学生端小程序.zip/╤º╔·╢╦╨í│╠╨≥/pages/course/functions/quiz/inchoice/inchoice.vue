<template>
	<view style="width: 100%;height: 1208upx;background: rgb(245, 246, 248);">
		<view style="height: 600upx;width: 100%;display: flex;justify-content: center;align-items: center;flex-direction: column;">
			<image src="../../../../../static/images/me.jpg" class="inchoice-img"></image>
			<text style="display: block;margin-top: 20upx;">顾润之</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.inchoice-img{
		height: 200upx;
		width: 200upx;
		border-radius: 50px;
		display: block;
	}
</style>
