<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<uni-popup :show="showPopupMiddle" :type="popType" v-on:hidePopup="hidePopup">
			<view class="uni-center" style="font-size:0;">
				<image style="width:300upx;height:300upx;" mode="widthFix" src="/static/images/QR_code.jpg" />
			</view>
			<view >
				<text>uf17124</text>
			</view>
		</uni-popup>
		<view class="function-top" style="border-top: 1px solid #E9E9E9;">
			<view class="function-top-teacher">
				<image src="../../../static/images/jianshang.jpg" class="teacher-img"></image>
				<text style="color:rgb(24, 153, 255)">孙小红</text>
			</view>
			<view class="function-top-content">
				<text style="font-size: 20px;float: left;margin-top: 20upx;margin-left: 15upx;">高等数学</text>
				<text style="font-size: 15px;margin-top: 15upx;float: left;color: rgb(83, 85, 85);margin-left: 15upx;">2018学年第一学期</text>
				<text style="font-size: 15px;margin-top: 24upx;float: left;color: rgb(83, 85, 85);margin-left: 15upx;">
					本课程开设时间是1-16周，属于考试课......
				</text>
				<text style="font-size: 15px;margin-top: 8upx;float: left;color: rgb(24, 153, 255);margin-left: 15upx;">查看详情</text>
			</view>
			<view class="function-top-change">
				<text class="bianji">编辑</text>
				<span class="iconfont erweima" @tap="showMiddlePopup">&#xe61b;</span>
			</view>
		</view>
		
		<view class="function-content">
			<view style="height: 33%;width: 100%;display: flex;flex-direction: row;">
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="task">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(255, 233, 172);">
							<text class="iconfont task">&#xe70f;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">课程任务</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="students">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(200, 242, 208);">
							<text class="iconfont student">&#xe620;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">班级学生</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="check">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(254, 226, 226);">
							<text class="iconfont task" style="color: rgb(253, 153, 153);">&#xe633;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);" >班级考勤</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="classwork">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(211, 238, 245);">
							<text class="iconfont task" style="color: rgb(87, 188, 219);">&#xe602;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">课堂作业</text>
				</view>
			</view>
			
			<view style="height: 33%;width: 100%;display: flex;flex-direction: row;">
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="quiz">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(254, 226, 226);">
							<text class="iconfont task" style="color: rgb(253, 153, 153);position: relative;left: -5upx;">&#xe61f;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">课堂提问</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="group">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(211, 238, 245);">
							<text class="iconfont task" style="color: rgb(84, 187, 219);">&#xe764;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">课堂小组</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;"  @tap="linkto" data-name="practise">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(200, 242, 208);">
							<text class="iconfont task" style="color: rgb(96, 217, 120);">&#xe616;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">在线练习</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="grade">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(255, 233, 172);">
							<text class="iconfont task" style="color: rgb(255, 158, 12);">&#xe656;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">成绩单</text>
				</view>
			</view>
			
			<view style="height: 33%;width: 100%;display: flex;flex-direction: row;">
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="wenjuan">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(211, 238, 245);">
							<text class="iconfont task" style="color: rgb(4, 208, 189);">&#xe636;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">调查问卷</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="video">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(255, 233, 172);">
							<text class="iconfont task" style="color: rgb(255, 152, 0);">&#xe626;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">视频直播</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;" @tap="linkto" data-name="activity">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(254, 226, 226);">
							<text class="iconfont task" style="color: rgb(253, 153, 153);">&#xe674;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">班级活动</text>
				</view>
				<view style="height: 100%;width: 25%;text-align: center;">
					<view style="height: 74%;width: 100%;">
						<view class="iconbox" style="background: rgb(200, 242, 208);">
							<text class="iconfont task" style="color: rgb(96, 217, 120);">&#xe60f;</text>
						</view>
					</view>
					<text style="font-size: 14px;color: rgb(83, 85, 85);">教学评估</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup.vue';
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				popType: 'middle',
				showPopupMiddle: false
			};
		},
		methods:{
			//统一的关闭popup方法
			hidePopup: function() {
				this.showPopupMiddle = false;
			},
			//展示居中 popup
			showMiddlePopup: function() {
				this.hidePopup();
				this.popType = 'middle';
				this.showPopupMiddle = true;
			},
			//跳转子功能页面
			linkto:function(event){
				var functionsName = event.currentTarget.dataset.name;
				uni.navigateTo({
					url:"/pages/course/functions/"+functionsName+"/"+functionsName
				})
			},
		},
		onShow() {
			getApp().gloabalData=undefined
		}
	}
</script>

<style>
	.student{
		font-size: 40px;
		border-radius: 100upx;
		color: rgb(96, 217, 120);
		position: relative;
		top: -7upx;
	}
	.task{
		font-size: 35px;
		border-radius: 100upx;
		color: rgb(255, 187, 0);
	}
	.iconbox{
		height: 140upx;
		width: 140upx ;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 100upx;
		float: left;
		margin: 12% 0px 0px 11%;
	}
	.function-content{
		height: 700upx;
		width: 100%;
		background: white;
		float: left;
		margin-top: 30upx;
	}
	.erweima{
		font-size: 32px;
		position: relative;
		top: 85upx;
		color: grey;
	}
	.bianji{
		border: 1px solid rgb(24, 153, 255);
		border-radius: 50upx;
		padding: 10upx 16upx;
		color: rgb(24, 153, 255);
		
	}
	.teacher-img{
		height: 170upx;
		width: 170upx;
		border-radius: 100upx;
		margin: 11% 9%;
	}
	.function-top-change{
		width: 22%;
		height: 92%;
		text-align: center;
		padding-top: 25upx;
	}
	.function-top-content{
		width: 48%;
		height: 100%;
	}
	.function-top-teacher{
		width: 30%;
		height: 100%;
		text-align: center;
	}
	.function-top{
		height: 310upx;
		width: 100%;
		background: white;
		display: flex;
		flex-direction: row;
	}
</style>
