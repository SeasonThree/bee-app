<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="blue-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view class="all-content">
			<view @tap="workto" style="width: 100%;height: 25%;float: left;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/classwork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">高数作业（4）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-11-04</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{text}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="workto">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/classwork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">高数作业（3）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-11-03</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="hasworked">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/haswork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">高数作业（2）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-11-02</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="hasworked">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/haswork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">高数作业（1）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-11-01</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">20:21:10</text>
				</view>
			</view>
		</view>
		<view style="width: 100%;text-align: center;float: left;margin-top: 50upx;font-size: 13px;color: #808080;">
			<text>已经到底啦(*╹▽╹*)</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				text:"未交"
			};
		},
		onShow() {
			let pages = getCurrentPages();
			let currPage = pages[pages.length - 1];
			if(currPage.data.text==undefined)
			{
				this.text='未交'
			}
			else
			this.text= currPage.data.text
		},
		methods:{
			workto:function(){
				uni.navigateTo({
					url: '/pages/course/functions/classwork/inwork/inwork'
				});
		},
		hasworked:function(){
			uni.showToast({
				title: '作业已过期',
				image:"/static/images/失败.png",
				icon:"none",
				duration: 1000
			});
		}
	},
}
</script>

<style>
	.blue-top{
		height: 150upx;
		width: 100%;
		background: #21B0FF;
		text-align: center;
	}
</style>
