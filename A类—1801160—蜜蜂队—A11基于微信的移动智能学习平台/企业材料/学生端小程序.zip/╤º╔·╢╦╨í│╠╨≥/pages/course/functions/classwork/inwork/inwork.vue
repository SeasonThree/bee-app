<template>
	<view>
		<swiper  style="height: 1200upx;width: 100%;" :current="current" @change="bindchange">
			<swiper-item>
				<view class="swiper-item">
					<view class="inwork-top">
						<text style="float: left;margin: 15upx 0upx 0upx 35upx;">1.计算题</text>
					</view>
					<view class="inwork-content">
						<image src="../../../../../static/images/inwork1.jpg" class="inwork-img"></image>
					</view>
					<view class="inwork-input">
						<input type="text"  placeholder="输入答案" />
					</view>
					<view class="inwork-bottom">
						<icon class="iconfont icon-plus">&#xe61a;</icon>
						<icon class="iconfont icon-plus">&#xe608;</icon>
						<icon class="iconfont icon-plus">&#xe659;</icon>
					</view>
				</view>
			</swiper-item>
			
			<swiper-item>
				<view class="swiper-item">
					<view class="swiper-item">
						<view class="inwork-top">
							<text style="float: left;margin: 15upx 0upx 0upx 35upx;">2.计算题</text>
						</view>
						<view class="inwork-content">
							<image src="../../../../../static/images/inwork2.jpg" class="inwork-img"></image>
						</view>
						<view class="inwork-input">
							<input type="text"  placeholder="输入答案" />
						</view>
						<view class="inwork-bottom">
							<icon class="iconfont icon-plus">&#xe61a;</icon>
							<icon class="iconfont icon-plus" @tap="cameraTo">&#xe608;</icon>
							<icon class="iconfont icon-plus">&#xe659;</icon>
						</view>
					</view>
				</view>
			</swiper-item>
		</swiper>
		<view class="inwork-deep">
			<view style="width: 25%;height: 100%;float: left;">
				<text class="iconfont deep-text" @tap="lastTo">{{text1}}</text>
			</view>
			<view style="width: 50%;height: 100%;float: left;">
				<text class="deep-text1">{{text2}}/2</text>
				<text class="deep-text2">答题卡</text>
			</view>
			<view style="float: left;width: 25%;height: 100%;">
				<text class="iconfont deep-text3" @tap="nextTo">{{text3}}</text>
			</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				text1:"",
				text2:"1",
				text3:"下一题 >",
				current:"0",
			};
		},
		methods:{
			nextTo:function(){
				var pages = getCurrentPages();  //获取第一张到目前的所有页面
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					text:'已交'
				});
				if(this.text3=="提交")
				{
					uni.showToast({
						title: '作业已提交',
						duration: 1000
					});
					setTimeout(function(){
						uni.navigateBack({
						delta: 1
						});
					},1500);
				}
				this.text1="< 上一题",
				this.text2="2",
				this.text3="提交",
				this.current="1"
			},
			lastTo:function(){
				this.text1="",
				this.text2="1",
				this.text3="下一题 >",
				this.current="0"
			},
			bindchange:function(e){
				this.current=e.detail.current;
				if(this.current=='0')
				{
					this.text1="",
					this.text2="1",
					this.text3="下一题 >"
				}
				else
				{
					this.text1="< 上一题",
					this.text2="2",
					this.text3="提交"
				}
			}
		}

	}
</script>

<style>
	.deep-text3{
		float: right;
		margin-top: 40upx;
		margin-right: 40upx;
	}
	.deep-text2{
		float: left;
		font-size: 15px;
		margin-top: 65upx;
		position: relative;
		right: 68upx;
	}
	.deep-text1{
		float: left;
		font-size: 15px;
		margin-left: 180upx;
		margin-top: 10upx;
	}
	.deep-text{
		float: left;
		margin-top: 40upx;
		margin-left: 40upx;
	}
	.inwork-deep{
		width: 100%;
		position: fixed;
		bottom: 0upx;
		height:120upx;
		color: #21B0FF;
	}
	.icon-plus{
		font-size: 60upx;
		float: left;
		margin: 12upx 30upx 0upx 40upx;
		color: rgb(113, 113, 113);
	}
	.inwork-bottom{
		width: 100%;
		height: 90upx;
		border-bottom: 1upx solid rgb(239, 239, 239);
	}
	.inwork-input{
		height: 480upx;
		width: 100%;
		border-bottom: 1upx solid rgb(239, 239, 239);
		padding-left: 40upx;
		padding-top: 40upx;
	}
	.inwork-img{
		width: 90%;
		height: 350upx;
		float: left;
		margin: 25upx 5%;
	}
	.inwork-content{
		height: 400upx;
		width: 100%;
		border-bottom: 1upx solid rgb(239, 239, 239);
	}
	.inwork-top{
		height: 60upx;
		width: 100%;
		background: rgb(245, 246, 248);
		color: #808080;
	}
</style>
