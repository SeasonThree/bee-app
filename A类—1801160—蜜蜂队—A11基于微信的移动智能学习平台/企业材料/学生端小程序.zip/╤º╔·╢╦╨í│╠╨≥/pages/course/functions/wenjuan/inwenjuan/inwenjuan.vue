<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view style="width: 100%;height: 300upx;background: white;border-top: 1px solid #E9E9E9;">
			<view style="width: 100%;height: 99upx;">
				<text style="float: left;margin: 25upx 5upx 0upx 30upx;color: #999999;">[单选题]</text>
				<text style="float: left;margin-top: 28upx;">是否把下午课程安排在上午？</text>
			</view>
			<view style="width: 90%;height: 2upx;background: #E9E9E9;margin-left: 5%;">
			</view>
			<view style="width: 100%;height: 99upx;" :class="{activeView:isactive}" @tap="colorChange">
				<icon class="iconfont icon-AB">&#xe645;</icon>
				<text style="float: left;margin-top: 36upx;">是</text>
			</view>
			<view style="width: 90%;height: 2upx;background: #E9E9E9;margin-left: 5%;">
			</view>
			<view style="width: 100%;height: 99upx;" :class="{activeView:isactive1}" @tap="colorChange1">
				<icon class="iconfont icon-AB">&#xe64b;</icon>
				<text style="float: left;margin-top: 36upx;">否</text>
			</view>
		</view>
		<view style="width: 100%;height: 100upx;float: left;margin-top: 70upx;">
			<button class="inwenjuan-button" @tap="buttonTap">提交</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isactive:false,
				isactive1:false
			};
		},
		methods:{
			colorChange:function(){
				if(this.isactive==false)
				{
					this.isactive=true;	
					this.isactive1=false;
				}
					
				else
					this.isactive=false;
			},
			colorChange1:function(){
				if(this.isactive1==false)
				{
					this.isactive1=true;
					this.isactive=false;
				}
						
				else
					this.isactive1=false;
			},
			buttonTap:function(){
				var pages = getCurrentPages();  //获取第一张到目前的所有页面
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					text:'已交'
				});
				uni.showModal({
					title: '提示',
					content: '是否提交问卷',
					success: function (res) {
					if (res.confirm) {
						console.log('用户点击确定');
						setTimeout(function(){
							uni.navigateBack({
							delta: 1
						});
					},500);
					} else if (res.cancel) {
						console.log('用户点击取消');
					}
				}
			});
				
			}
		}
	}
</script>

<style>
	.inwenjuan-button{
		background: #21B0FF;
		width: 90%;
		color: white;
	}
	.activeView{
		width: 100%;
		height: 34%;
		color: #007AFF;
	}
	.icon-AB{
		font-size: 50upx;
		float: left;
		margin:25upx 20upx 0upx 30upx;
	}
</style>
