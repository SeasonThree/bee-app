<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="blue-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view class="all-content">
			<view @tap="activityTo" style="width: 100%;height: 25%;float: left;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/wenjuan.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">元旦活动</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-23</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{text}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">15:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="activityTo">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/wenjuan.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">秋游</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-21</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">14:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="activitied">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/wenjuan1.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">春游</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-12</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">16:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="activitied">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/wenjuan1.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">五一活动</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-11</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">14:21:10</text>
				</view>
			</view>
		</view>
		<view style="width: 100%;text-align: center;float: left;margin-top: 50upx;font-size: 13px;color: #808080;">
			<text>已经到底啦(*╹▽╹*)</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				text:"未交"
			};
		},
		onShow() {
			let pages = getCurrentPages();
			let currPages = pages[pages.length - 1];
			if(currPages.data.text==undefined)
			{
				this.text="未交"
			}
			else
				this.text=currPages.data.text
		},
		methods:{
			activitied:function(){
				uni.showToast({
					title: '活动已过期',
					image:"/static/images/失败.png",
					icon:"none",
					duration: 1000
				});
			},
			activityTo:function(){
				uni.navigateTo({
					url:"/pages/course/functions/activity/inactivity/inactivity"
				})
			}
		}
	}
</script>

<style>

</style>
