<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="inactivity-top">
			<view :class="{activeTopApart:istrue,inactivityTopApart:isfalse}" style="border-right: 1px solid #E9E9E9;" @tap="tapTo1">
				<text>活动详情</text>
			</view>
			<view :class="{activeTopApart:isfalse,inactivityTopApart:istrue}" @tap="tapTo2">
				<text>报名人数</text>
			</view>
		</view>
		<swiper style="height: 800upx;width: 100%;" :current="current" @change="bindchange">
			<swiper-item >
				<view style="width: 100%;height: 250upx;background: white;border-bottom: 1px solid #E9E9E9;">
					<text class="inactivity-text">元旦班长打算计划出去玩，选择了合适的场所以及全天自助式烧烤，酒店内会准时提供火锅，有想法的一起约起来。</text>
				</view>
				<view class="inactivity-time">
					<text>报名截止于2019-12-10 20:21</text>
				</view>
			</swiper-item>
			<swiper-item>
				<view style="width: 100%;height: 80upx;">
					<text style="float: left;margin: 20upx 30upx 0upx;color: green;">已报名：4人</text>
				</view>
				<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
					<view style="float: left;">
						<image src="/static/images/jianshang.jpg" class="student-teacher"></image>
					</view>
					<view style="height: 70upx;width: 70%;float: left;">
						<text style="float: left;margin: 23upx 0upx 17upx 5upx;">楚若黎</text>
						<span class="iconfont icon-yezi" >&#xe601;</span>
					</view>
					<view style="height: 60upx;width: 60%;">
						<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082312</text>
						</view>
				</view>
				<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
					<view style="float: left;">
						<image src="/static/images/mama.jpg" class="student-teacher"></image>
					</view>
					<view style="height: 70upx;width: 70%;float: left;">
						<text style="float: left;margin: 23upx 0upx 17upx 5upx;">顾润之</text>
						<span class="iconfont icon-yezi" >&#xe601;</span>
					</view>
					<view style="height: 60upx;width: 60%;">
						<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082313</text>
						</view>
				</view>
				<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
					<view style="float: left;">
						<image src="/static/images/lishi.jpg" class="student-teacher"></image>
					</view>
					<view style="height: 70upx;width: 70%;float: left;">
						<text style="float: left;margin: 23upx 0upx 17upx 5upx;">楚秋然</text>
						<span class="iconfont icon-yezi" >&#xe601;</span>
					</view>
					<view style="height: 60upx;width: 60%;">
						<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082314</text>
						</view>
				</view>
				<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);float: left;">
					<view style="float: left;">
						<image src="/static/images/xinli.jpg" class="student-teacher"></image>
					</view>
					<view style="height: 70upx;width: 70%;float: left;">
						<text style="float: left;margin: 23upx 0upx 17upx 5upx;">愧泽</text>
						<span class="iconfont icon-yezi" >&#xe601;</span>
					</view>
					<view style="height: 60upx;width: 50%;">
						<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082315</text>
					</view>
				</view>
			</swiper-item>
			
		</swiper>
		<view class="inactivity-bottom">
			<button :class="{activeButton:buttonId}" class="bottomButton" style="width: 90%;line-height: 70upx;" @tap="buttonTo">{{text}}</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current:"0",
				istrue:true,
				isfalse:false,
				text:"立即报名",
				buttonId:false
			};
		},
		methods:{
			tapTo1:function(){
				this.current="0";
				this.istrue=true;
				this.isfalse=false
			},
			tapTo2:function(){
				this.current="1";
				this.istrue=false;
				this.isfalse=true;
			},
			bindchange:function(e){
				this.current=e.detail.current;
				if(this.current=="0")
				{
					this.istrue=true;
					this.isfalse=false
				}
				else
				{
					this.istrue=false;
					this.isfalse=true;
				}
			},
			buttonTo:function(){
				var pages = getCurrentPages();
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					text:'已交'
				});
				if(this.buttonId==false)
				{
					this.text="取消报名";
					this.buttonId=true
				}
				else
				{
					this.text="立即报名";
					this.buttonId=false;
				}
				
				
			}
		}
	}
</script>

<style>
	.bottomButton{
		background:rgb(232, 54, 60);
		color: white;
	}
	.activeButton{
		background:rgb(179, 174, 174);
		color: white;
	}
	.activeTopApart{
		width: 50%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		background: #007AFF;
		color: white;
	}
	.inactivityTopApart{
		width: 50%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		
	}
	.student-teacher{
		height: 100upx;
		width: 100upx;
		margin: 20upx 20upx 0upx 30upx;
		border-radius: 10upx;
	}
	.icon-yezi{
	  color: rgb(135, 214, 16);
	}
	.inactivity-bottom{
		position: fixed;
		bottom: 0upx;
		width: 100%;
		height: 120upx;
		display: flex;
		align-items: center;
		justify-content: center;
		background: white;
		border-top: 1px solid #E9E9E9;
	}
	.inactivity-time{
		width: 90%;
		height: 50upx;
		float: left;
		margin: 20upx 5%;
		border-radius: 30upx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 32upx;
		background: rgb(223, 247, 195);
		color: rgb(163, 228, 87);
	}
	.inactivity-text{
		float: left;
		margin: 10upx 24upx;
		font-size: 34upx;
		line-height: 70upx;
	}
	.inactivity-top{
		width: 100%;
		height: 100upx;
		display: flex;
		flex-direction: row;
		background: white;
		border: 1px solid #E9E9E9;
	}
</style>
