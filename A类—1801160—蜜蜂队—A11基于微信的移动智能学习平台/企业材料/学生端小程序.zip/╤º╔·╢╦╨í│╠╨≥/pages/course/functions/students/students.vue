<template>
	<view style="height: 1200upx;background: rgb(245, 246, 248);">
		<view class="blue-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view style="height: 80upx;width: 100%;margin: 40upx 0upx;">
			<view class="all-search">
			  <input class='all-seach1' placeholder='搜索'></input>
			  <icon class="iconfont icon-sousuo">&#xe61c;</icon>
			</view>
		</view>
		<view style="height: 55upx;width: 100%;">
			<text style="font-size: 15px;margin-left: 30upx;color: grey;">教师 (1人)</text>
		</view>
		<view style="height: 140upx;width: 100%;background: white;">
			<view style="float: left;">
				<image src="../../../../static/images/jianshang.jpg" class="student-teacher"></image>
			</view>
			<text style="float: left;margin: 48upx 5upx;">孙小红</text>
		</view>
		<view style="height: 55upx;width: 100%;margin-top: 20upx;">
			<text style="font-size: 15px;margin-left: 30upx;color: grey;">学生 (4人)</text>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);">
			<view style="float: left;">
				<image src="../../../../static/images/mama.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">楚若黎</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 60%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082312</text>
				</view>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);">
			<view style="float: left;">
				<image src="../../../../static/images/me.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">顾润之</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 60%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082313</text>
				</view>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);">
			<view style="float: left;">
				<image src="../../../../static/images/lishi.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">楚秋然</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 60%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082314</text>
				</view>
		</view>
		<view style="height: 140upx;width: 100%;background: white;border-bottom: 1px solid rgb(246, 246, 246);">
			<view style="float: left;">
				<image src="../../../../static/images/xinli.jpg" class="student-teacher"></image>
			</view>
			<view style="height: 70upx;width: 70%;float: left;">
				<text style="float: left;margin: 23upx 0upx 17upx 5upx;">愧泽</text>
				<span class="iconfont icon-yezi" >&#xe601;</span>
			</view>
			<view style="height: 60upx;width: 50%;">
				<text style="font-size: 15px; color: rgb(33, 176, 255);">2017082315</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.icon-yezi{
	  color: rgb(135, 214, 16);
	}
	.student-teacher{
		height: 100upx;
		width: 100upx;
		margin: 20upx 20upx 0upx 30upx;
		border-radius: 10upx;
	}
</style>
