<template>
	<view style="height: 1200upx;width: 100%;background: rgb(245, 246, 248);">
		<view class="blue-top">
			<view style="float: left;margin: 40upx 0upx 0upx 27%;color: white;font-size: 17px;">
				<text style="display: block;margin-bottom: 20upx;">高等数学</text>
				<text>2017-2018年第一学期</text>
			</view>
		</view>
		<view class="all-content">
			<view @tap="practiseTo" style="width: 100%;height: 25%;float: left;border-top:1px solid rgb(242, 242, 242) ;border-bottom:1px solid rgb(242, 242, 242) ;">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/classwork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">练习卷（4）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-23</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">{{text}}</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">15:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="practiseTo">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/classwork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">练习卷（3）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-21</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">14:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="practised">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/haswork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">练习卷（2）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-12</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">16:21:10</text>
				</view>
			</view>
			<view style="width: 100%;height: 25%;float: left;border-bottom:1px solid rgb(242, 242, 242) ;" @tap="practised">
				<view style="height: 100%;width:150upx;float: left;">
					<image src="../../../../static/images/haswork.jpg" class="all-img"></image>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 30upx 0upx;float: left;font-size: 16px;">练习卷（1）</text>
					<text style="margin: 30upx 20upx;float: right;font-size: 16px;">2018-10-11</text>
				</view>
				<view style="height: 50%;width: 80%;float: left;">
					<text style="margin: 12upx 0upx;float: left;font-size: 13px;color: #808080;">已交</text>
					<text style="margin: 12upx 50upx;float: right;font-size: 13px;color: #808080;">14:21:10</text>
				</view>
			</view>
		</view>
		<view style="width: 100%;text-align: center;float: left;margin-top: 50upx;font-size: 13px;color: #808080;">
			<text>已经到底啦(*╹▽╹*)</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				text:"未交"
			};
		},
		onShow() {
			let pages = getCurrentPages();
			let currPage = pages[pages.length - 1];
			if(currPage.data.text==undefined)
			{
				this.text='未交'
			}
			else
			this.text= currPage.data.text
		},
		methods:{
			practised:function(){
				uni.showToast({
					title: '练习已过期',
					image:"/static/images/失败.png",
					icon:"none",
					duration: 1000
				});
			},
			practiseTo:function(){
				uni.navigateTo({
					url:"/pages/course/functions/practise/inpractise/inpractise"
				});
			}
		}
	}
</script>

<style>
	
</style>
