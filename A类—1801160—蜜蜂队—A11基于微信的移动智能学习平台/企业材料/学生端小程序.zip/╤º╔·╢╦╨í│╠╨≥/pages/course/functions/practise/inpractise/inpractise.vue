<template>
	<view style="width: 100%;height: 1100upx;background:rgb(245, 246, 248) ;">
		<swiper  style="height: 1200upx;width: 100%;" :current="current" @change="bindchange">
			<swiper-item>
				<view :style="{display: activeDisplay}" id="first">
						<view style="width: 100%;height: 60upx;">
							<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">1.判断题</text>
						</view>
						<view style="width: 100%;height: 250upx;background: white;">
							<view style="width: 100%;height:32%;">
								<text style="margin:20upx 0upx 0upx 60upx;float: left;">1+1=12</text>
								<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
							</view>
							<view style="width: 100%;height: 34%;color: red;">
								<icon class="iconfont icon-AB">&#xe645;</icon>
								<text style="float: left;margin-top: 12upx;">对</text>
							</view>
							<view style="width: 100%;height: 34%;">
								<icon class="iconfont icon-AB">&#xe64b;</icon>
								<text style="float: left;margin-top: 12upx;">错</text>
							</view>
						</view>
						<view style="width: 100%;height: 60upx;">
							<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">2.判断题</text>
						</view>
						<view style="width: 100%;height: 250upx; background: white;">
							<view style="width: 100%;height:32%;">
								<text style="margin:20upx 0upx 0upx 60upx;float: left;">2+2=8</text>
								<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
							</view>
							<view style="width: 100%;height: 34%;color: red;" >
								<icon class="iconfont icon-AB">&#xe645;</icon>
								<text style="float: left;margin-top: 12upx;">对</text>
							</view>
							<view style="width: 100%;height: 34%;" >
								<icon class="iconfont icon-AB">&#xe64b;</icon>
								<text style="float: left;margin-top: 12upx;">错</text>
							</view>
						</view>
						<view style="width: 100%;height: 60upx;">
							<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">3.判断题</text>
						</view>
						<view style="width: 100%;height: 250upx; background: white;">
							<view style="width: 100%;height:32%;">
								<text style="margin:20upx 0upx 0upx 60upx;float: left;">10+2=12</text>
								<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
							</view>
							<view style="width: 100%;height: 34%;color: green;" >
								<icon class="iconfont icon-AB">&#xe645;</icon>
								<text style="float: left;margin-top: 12upx;">对</text>
							</view>
							<view style="width: 100%;height: 34%;" >
								<icon class="iconfont icon-AB">&#xe64b;</icon>
								<text style="float: left;margin-top: 12upx;">错</text>
							</view>
						</view>
				</view>
				<view :style="{display: anotherDisplay}" id="second">
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">1.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx;background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">1+1=12</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;" :class="{activeView:isactive}" @tap="colorChange">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;" :class="{activeView:isactive1}" @tap="colorChange1">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">2.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx; background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">2+2=8</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;" :class="{activeView:isactive2}" @tap="colorChange2">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;" :class="{activeView:isactive3}" @tap="colorChange3">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">3.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx; background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">10+2=12</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;" :class="{activeView:isactive4}" @tap="colorChange4">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;" :class="{activeView:isactive5}" @tap="colorChange5">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
				</view>
			</swiper-item>
			
			<swiper-item>
				<view :style="{display:activeDisplay}">
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">1.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx;background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">1+1=12</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;color: red;">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">2.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx; background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">2+2=8</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;color: green;">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">3.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx; background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">10+2=12</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;color: green;">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
				</view>
				<view :style="{display: anotherDisplay}">
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">1.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx;background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">1+1=12</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;color:green;">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">2.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx; background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">2+2=8</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;color: green;">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
					<view style="width: 100%;height: 60upx;">
						<text style="font-size: 32upx;margin:14upx 32upx 0upx;float: left;">3.判断题</text>
					</view>
					<view style="width: 100%;height: 250upx; background: white;">
						<view style="width: 100%;height:32%;">
							<text style="margin:20upx 0upx 0upx 60upx;float: left;">10+2=12</text>
							<text style="font-size: 32upx;color: #C8C7CC;float: left;margin-top:21upx">(本题1分)</text>
						</view>
						<view style="width: 100%;height: 34%;color: green;">
							<icon class="iconfont icon-AB">&#xe645;</icon>
							<text style="float: left;margin-top: 12upx;">对</text>
						</view>
						<view style="width: 100%;height: 34%;">
							<icon class="iconfont icon-AB">&#xe64b;</icon>
							<text style="float: left;margin-top: 12upx;">错</text>
						</view>
					</view>
				</view>
			</swiper-item>
		</swiper>
		<view class="inwork-deep">
			<view style="width: 25%;height: 100%;float: left;">
				<text class="iconfont deep-text" @tap="lastTo">{{text1}}</text>
			</view>
			<view style="width: 50%;height: 100%;float: left;">
				<text class="deep-text1">{{text2}}/2</text>
				<text class="deep-text2">答题卡</text>
			</view>
			<view style="float: left;width: 25%;height: 100%;">
				<text class="iconfont deep-text3" @tap="nextTo">{{text3}}</text>
			</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				activeDisplay:'none',
				anotherDisplay:"block",
				text1:"",
				text2:"1",
				text3:"下一题 >",
				current:"0",
				isactive:false,
				isactive1:false,
				isactive2:false,
				isactive3:false,
				isactive4:false,
				isactive5:false
			};
		},
		methods:{
			nextTo:function(){
				var pages = getCurrentPages();  //获取第一张到目前的所有页面
				var currPage = pages[pages.length - 1];  //获取当前页面
				var prevPage = pages[pages.length - 2];	 //获取前一张页面
				prevPage.setData({
					text:'已交'
				});
				if(this.text3=="提交")
				{
					uni.showToast({
						title: '练习已提交',
						duration: 1000
					});
					
					this.activeDisplay="block",
					this.anotherDisplay="none",
					this.current="0"
				}
				else
				{
					this.text1="< 上一题",
					this.text2="2",
					this.text3="提交",
					this.current="1"
				}
				
			},
			lastTo:function(){
				this.text1="",
				this.text2="1",
				this.text3="下一题 >",
				this.current="0"
			},
			bindchange:function(e){
				this.current=e.detail.current;
				if(this.current=='0')
				{
					this.text1="",
					this.text2="1",
					this.text3="下一题 >"
					
				}
				else
				{
					this.text1="< 上一题",
					this.text2="2",
					this.text3="提交"
				}
			},
			colorChange:function(){
				if(this.isactive==false)
				{
					this.isactive=true;	
					this.isactive1=false;
				}
					
				else
					this.isactive=false;
			},
			colorChange1:function(){
				if(this.isactive1==false)
				{
					this.isactive1=true;
					this.isactive=false;
				}
						
				else
					this.isactive1=false;
			},
			colorChange2:function(){
				if(this.isactive2==false)
				{
					this.isactive2=true;	
					this.isactive3=false;
				}
					
				else
					this.isactive2=false;
			},
			colorChange3:function(){
				if(this.isactive3==false)
				{
					this.isactive3=true;
					this.isactive2=false;
				}
						
				else
					this.isactive3=false;
			},
			colorChange4:function(){
				if(this.isactive4==false)
				{
					this.isactive4=true;	
					this.isactive5=false;
				}
					
				else
					this.isactive4=false;
			},
			colorChange5:function(){
				if(this.isactive5==false)
				{
					this.isactive5=true;
					this.isactive4=false;
				}
						
				else
					this.isactive5=false;
			}
		}
	
	}
</script>

<style>
	.activeView{
		width: 100%;
		height: 34%;
		color: green;
	}
	.icon-AB{
		font-size: 56upx;
		float: left;
		margin:0upx 30upx 0upx 60upx;
	}
	.deep-text3{
		float: right;
		margin-top: 40upx;
		margin-right: 40upx;
	}
	.deep-text2{
		float: left;
		font-size: 15px;
		margin-top: 65upx;
		position: relative;
		right: 68upx;
	}
	.deep-text1{
		float: left;
		font-size: 15px;
		margin-left: 180upx;
		margin-top: 10upx;
	}
	.deep-text{
		float: left;
		margin-top: 40upx;
		margin-left: 40upx;
	}
	.inwork-deep{
		width: 100%;
		position: fixed;
		bottom: 0upx;
		height:120upx;
		color: #21B0FF;
		border: 1px solid #CCCCCC;
		background: white;
	}
	
</style>
