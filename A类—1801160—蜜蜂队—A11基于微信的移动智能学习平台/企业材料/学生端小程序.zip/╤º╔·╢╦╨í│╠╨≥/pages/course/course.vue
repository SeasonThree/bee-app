<template>
	<view class='course-container'>
		<view class="course-search" style="border-top: 1px solid #E9E9E9;">
			<input class='course-seach1' placeholder='搜索'></input>
			<icon class="iconfont icon-sousuo">&#xe61c;</icon>
		</view>
	<view class='course-body'>
		<view class='course-body1' @tap="linkto1">
			<image src="/static/images/jianshang.jpg" class="course-images"></image>
			<text class='course-name'>高等数学</text>
			<text class='course-teacher1'>孙小红</text>
		</view>
		<view class='course-body1'>
			<image src="/static/images/chadao.jpg" class="course-images"></image>
			<text class='course-name'>茶道品析</text>
			<text class='course-teacher1'>张全蛋</text>
		</view>
		<view class='course-body1'>
			<image src="/static/images/shougong.jpg" class="course-images"></image>
			<text class='course-name'>手工艺术</text>
			<text class='course-teacher1'>王小绿</text>
		</view>
		<view class='course-body1'>
			<image src="/static/images/mama.jpg" class="course-images"></image>
			<text class='course-name'>大学英语（3）</text>
			<text class='course-teacher'>赵铁柱</text>
		</view>
    
		<view class='course-body1'>
			<image src="/static/images/test.jpg" class="course-images"></image>
			<text class='course-name'>大学语文</text>
			<text class='course-teacher1'>林大大</text>
		</view>
		<navigator url='/pages/course/delete-course/delete-course' open-type='navigate'>
			<view class='course-body1'>
				<span class="iconfont icon-wenjianjia" >&#xe723;</span>
				<text class='course-name1'>已删除课程</text>
			</view>
		</navigator>
	</view>
			<view>
				<uni-fab 
            :pattern="pattern"
            :content="content"
            :horizontal="horizontal"
            :vertical="vertical"
            :direction="direction"
            @trigger="trigger"
        ></uni-fab>
			</view>
</view>
</template>

<script>
	
import uniFab from '@/components/uni-fab/uni-fab.vue';
const app=getApp()
export default {
    data() {
        return {
			mark:'',
            horizontal: 'right',
            vertical: 'bottom',
            direction: 'vertical',
            pattern: {
                color: '#7A7E83',
                backgroundColor: '#fff',
                selectedColor: '#8A8A8A',
                buttonColor:"white"
            },
            content: [
                {
                    iconPath: '/static/images/scan.png',
                    selectedIconPath: '/static/images/scan.png',
                    text: '扫一扫',
                    active: false
                },
                {
                    iconPath: '/static/images/number.png',
                    selectedIconPath: '/static/images/number.png',
                    text: '邀请码',
                    active: false
                }
            ]
        };
    },
    methods: {
			linkto1: function () {
			  uni.navigateTo({
			    url: '/pages/course/functions/functions',
			  })
			},

        trigger(e) {
            console.log(e);
            this.content[e.index].active = !e.item.active;
						if(e.item.text=="扫一扫")
						{
							app.gloabalData="marked"
							uni.scanCode({
								scanType:"qrCode",
								success: function (res) {
								console.log('条码类型：' + res.scanType);
								console.log('条码内容：' + res.result);
																		console.log('markbeforeqr='+app.gloabalData);
								
								app.gloabalData="marked"
										console.log('markafterqr='+app.gloabalData);//这些语句都是在下一个页面打开后才运行的？？
								
								uni.navigateTo({
								url:"/pages/course/course"
								})
								}
							});
						}
						else
						{
							uni.navigateTo({
								url:"/pages/course/invitation-code/invitation-code"
							})
						}
            
        }
    },
    components: {
        uniFab
    },
	onShow() {
		console.log('mark1='+app.gloabalData);
		if(app.gloabalData=='marked'){
			uni.showToast({
				title: '已加入课堂',
				mask: false,
				duration: 1500
			});
		}
	},
// 	onHide() {
// 		console.log('coursehidebeforechange='+app.gloabalData);
// 		if(app.gloabalData!='')
// 			app.gloabalData=undefined
// 		
// 		console.log('afterchange='+app.gloabalData);
// 	}
};
	
</script>

<style>
		.course-container{
			background-color:white;
			height: 1200upx;
			width: 100%;

		}
		.course-search{
			height: 100upx;
			width: 100%;
			margin: auto;
		}
		.course-seach1{
			z-index: 0;
			height: 60upx;
			width: 600upx;
			background-color: rgb(245, 246, 248);
			margin:auto;
			position: relative;
			top: 20upx;
			font-size:25upx; 
			border-radius: 40upx;
			text-align: center;
		}
		.course-search .icon-sousuo{
			position: relative;
			left: 310upx;
			top: -52upx;
			z-index: 1;
		}
		.course-body{
			position: relative;
			height: 790upx;
			width: 100%;
		}
		.course-body1{
			height: 130upx;
			width: 100%;
			border-bottom: 1px solid rgb(241, 241, 241);
		}
		.course-images{
			height:100upx;
			width: 100upx;
			border-radius: 40px;
			position: relative;
			top: 14upx;
			left: 30upx;
		}
		.course-name{
			font-size: 36upx;
			position: relative;
			top: -50upx;
			left: 82upx;
		}
		.course-teacher{
			font-size: 25upx;
			position: relative;
			left:-150upx;  
			color: rgb(170, 168, 168);
		}
		.course-teacher1{
			font-size: 25upx;
			position: relative;
			left:-61upx;  
			color: rgb(170, 168, 168);  
		}
		.icon-wenjianjia{
			font-size: 90upx;
			position: relative;
			top: 15upx;
			left: 34upx;
			color: grey;
		}
		.course-name1{
			font-size: 34upx;
			position: relative;
			top: -5upx;
			left: 80upx;
		}
</style>
