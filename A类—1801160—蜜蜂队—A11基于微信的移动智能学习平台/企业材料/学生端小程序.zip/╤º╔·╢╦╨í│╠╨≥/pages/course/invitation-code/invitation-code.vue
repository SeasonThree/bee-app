<template>
	<view style="background:rgb(230, 233, 238);height: 1208upx;">
		<view style="width: 100%;height: 350upx;">
			<input type="text" placeholder="请输入邀请码" class="code-input"/>
		</view>
		<view style="width: 100%;">
			<button type="primary" style="width: 90%;margin: 0upx 5%;background:blue" @tap="buttonTo">确定</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			buttonTo:function(){
				uni.showToast({
					title: '成功进入该课程',
					duration: 1000
				});
				setTimeout(function() {
					uni.navigateBack({
						delta:1
					})
				}, 1500);
			}
			
		}
	}
</script>

<style>
.code-input{
	border: 1px solid #999999;
	height: 80upx;
	width: 90%;
	float: left;
	margin: 30% 5% 0%;
}
</style>
