<template>
	<view class="delete-course">
		<view class='delete-time' style="border-top: 1px solid #E9E9E9;">
			<text class='delete-time-text1'>2017-2018学年</text>
			<text class='delete-time-text2'>（大一）第一学期</text>
		</view>
			<view class='delete-course-body1'>
				<image src="/static/images/cyuyan.jpg" class="delete-course-images"></image>
				<text class='delete-course-name'>C语言程序设计基础</text>
				<text class='delete-course-teacher'>赵铁柱</text>
			</view>
			<view class='delete-course-body1'>
				<image src="/static/images/lishi.jpg" class="delete-course-images"></image>
				<text class='delete-course-name'>中外历史人物论</text>
				<text class='delete-course-teacher1'>华阳真</text>
			</view>
			<view class='delete-course-body1'>
				<image src="/static/images/ps.jpg" class="delete-course-images"></image>
				<text class='delete-course-name'>PS实践教程</text>
				<text class='delete-course-teacher2'>蓝牡丹</text>
			</view>
			<view class='delete-course-body1'>
				<image src="/static/images/xinli.jpg" class="delete-course-images"></image>
				<text class='delete-course-name'>大学生心理健康教育</text>
				<text class='delete-course-teacher3'>小豆豆</text>
			</view>
			<view class='delete-course-jianxi'></view>
		<view class='delete-time'>
			<text class='delete-time-text1'>2017-2018学年</text>
			<text class='delete-time-text2'>（大一）第二学期</text>
		</view>
		<view class='copy-course-body1'>
				<image src="/static/images/mama.jpg" class="copy-course-images"></image>
				<text class='copy-course-name'>大学英语（1）</text>
				<text class='copy-course-teacher'>赵铁柱</text>
			</view>
			<view class='copy-course-body1'>
				<image src="/static/images/mama.jpg" class="copy-course-images"></image>
				<text class='copy-course-name'>大学英语（2）</text>
				<text class='copy-course-teacher'>赵铁柱</text>
			</view>
			<view class='copy-course-body1'>
				<image src="/static/images/test.jpg" class="copy-course-images"></image>
				<text class='copy-course-name'>英语翻译（1）</text>
				<text class='copy-course-teacher'>赵铁柱</text>
			</view>
			<view class='copy-course-body1'>
				<image src="/static/images/test.jpg" class="copy-course-images"></image>
				<text class='copy-course-name'>英语听力（2）</text>
				<text class='copy-course-teacher'>赵铁柱</text>
			</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.delete-course{
  width: 100%;
  height: 680px;
}
.delete-time{
  height: 150upx;
  width: 100%;
  text-align: center;
  border-bottom: 1px solid rgb(241, 241, 241);
}
.delete-time-text1{
  position: relative;
  font-size: 34upx;
  top: 25upx;
  display: block;
}
.delete-time-text2{
  position: relative;
  font-size: 34upx;
  top: 50upx;
  left: -12upx;
}

.delete-course-body1{
  height: 150upx;
  width: 100%;
  border-bottom: 1px solid rgb(241, 241, 241);
}
.delete-course-images{
  height:100upx;
  width: 100upx;
  border-radius: 40px;
  position: relative;
  top: 28upx;
  left: 30upx;
}
.delete-course-name{
  font-size: 36upx;
  position: relative;
  top: -40upx;
  left: 70upx;
}
.delete-course-teacher{
  font-size: 25upx;
  position: relative;
  left:-238upx;  
  color: rgb(170, 168, 168);
  top: 14upx;
}
.delete-course-teacher1{
  font-size: 25upx;
  position: relative;
  left:-180upx;  
  color: rgb(170, 168, 168);
  top: 14upx; 
}
.delete-course-teacher2{
  font-size: 25upx;
  position: relative;
  left:-118upx;  
  color: rgb(170, 168, 168);
  top: 14upx; 
}
.delete-course-teacher3{
  font-size: 25upx;
  position: relative;
  left:-254upx;  
  color: rgb(170, 168, 168);
  top: 14upx; 
}
.delete-course-jianxi{
  height: 30upx;
  width: 100%;
  background-color: rgb(248, 248, 248);
}
.copy-course-body1{
  height: 150upx;
  width: 100%;
  border-bottom: 1px solid rgb(241, 241, 241);
}
.copy-course-images{
  height:100upx;
  width: 100upx;
  border-radius: 40px;
  position: relative;
  top: 28upx;
  left: 30upx;
}
.copy-course-name{
  font-size: 36upx;
  position: relative;
  top: -40upx;
  left: 70upx;
}
.copy-course-teacher{
  font-size: 25upx;
  position: relative;
  left:-166upx;  
  color: rgb(170, 168, 168);
  top: 14upx;
}
</style>
