<template>
	<view style="background: rgb(245, 246, 248);height: 1208upx;">
		<view class="person-all" style="border-top: 1px solid #E9E9E9;">
			<text class="person-text">姓名</text>
			<text class="person-text" style="color: #0099FF;">顾润之</text>
		</view>
		<view class="person-all" style="border-top: 1px solid #E9E9E9;">
			<text class="person-text">性别</text>
			<text class="person-text" style="color: #999999;">男</text>
			<icon class="iconfont person-text"  style="float: right;font-size: 36upx;">&#xe630;</icon>
		</view>
		<view class="person-all" style="border-top: 1px solid #E9E9E9;">
			<text class="person-text">描述</text>
			<text class="person-text" style="color: #999999;">蜜蜂队加油！</text>
			<icon class="iconfont person-text"  style="float: right;font-size: 36upx;">&#xe630;</icon>
		</view>
		
		<view class="person-all" style="margin-top: 24upx;">
			<text class="person-text">手机号</text>
			<text class="person-text" style="color: #999999;">178XXXXXX53</text>
			<icon class="iconfont person-text"  style="float: right;font-size: 36upx;">&#xe630;</icon>
		</view>
		<view class="person-all" style="border-top: 1px solid #E9E9E9;">
			<text class="person-text">所属院校</text>
			<text class="person-text" style="color: #999999;">百花谷落英学院</text>
			<icon class="iconfont person-text"  style="float: right;font-size: 36upx;">&#xe630;</icon>
		</view>
		<button type="primary" style="background: red;width: 90%;margin: 0upx 5%;position:fixed;bottom: 10upx;">退出登录</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.person-all{
	  height: 118upx;
	  width: 100%;
	  background-color:white;
	}
	.person-text{
	  float: left;
	  margin: 5% 4% 0upx;
	}
</style>
