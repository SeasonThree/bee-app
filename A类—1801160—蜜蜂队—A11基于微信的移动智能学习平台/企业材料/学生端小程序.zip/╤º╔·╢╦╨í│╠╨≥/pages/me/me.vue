<template>
	<view class="me">
  <view class='me-top'>
    <image src="/static/images/me.jpg" class='me-image'></image>
    <text class='me-name'>顾润之</text>
    <span class="iconfont icon-yezi" >&#xe601;</span>
    <span class="iconfont icon-erweima" >&#xe61b;</span>
  </view>
	
  <view class='me-all' @tap="personTo">
    <span class="iconfont icon-gerenxinxi " >&#xe613;</span>
    <text class='me-xinxiall' >个人信息</text>
    <span class="iconfont icon-xiangyou icon-jiantou" >&#xe630;</span>
  </view>
	
   <view class='me-all'>
    <span class="iconfont icon-xiaozu " >&#xe764;</span>
    <text class='me-xinxiall'>小组</text>
    <span class="iconfont icon-xiangyou icon-jiantou" >&#xe630;</span>
  </view>
  <view class='me-cover'>
    <span class="iconfont icon-shuben " >&#xe603;</span>
    <text class='me-xinxiall'>收藏</text>
    <span class="iconfont icon-xiangyou icon-jiantou" >&#xe630;</span>
  </view>
	
  <view class='me-all' @tap="linkTo" data-name="wenjuan">
    <span class="iconfont icon-wenjuan " >&#xe636;</span>
    <text class='me-xinxiall'>问卷调查</text>
    <span class="iconfont icon-xiangyou icon-jiantou" >&#xe630;</span>
  </view>
  <view class='me-cover' >
    <span class="iconfont icon-xinxi " >&#xe614;</span>
    <text class='me-xinxiall'>个人消息</text>
    <span class="iconfont icon-xiangyou icon-jiantou" >&#xe630;</span>
  </view>
  <view class='me-cover'>
    <span class="iconfont icon-shouce- " >&#xe617;</span>
    <text class='me-xinxiall'>操作手册</text>
    <span class="iconfont icon-xiangyou icon-jiantou" >&#xe630;</span>
  </view>
</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			linkTo:function(event){
				var functionsName = event.currentTarget.dataset.name;
				uni.navigateTo({
					url:"/pages/course/functions/"+functionsName+"/"+functionsName
				})
			},
			personTo:function(){
				uni.navigateTo({
					url:"/pages/me/personMessage/personMessage"
				})
			}
		},
		onShow() {
			getApp().gloabalData=undefined
		}
	}
</script>

<style>
	.me{
  height: 1100upx;
  width: 100%;
  background-color: rgb(245, 246, 248 );
  padding-top: 24upx;
}
.me-top{
  height: 180upx;
  width: 100%;
  background-color: white;
  font-size: 38upx;
}
.me-image{
  position: relative;
  top: 24upx;
  left: 40upx;
  height: 130upx;
  width: 130upx;
  border-radius: 100upx;
	border: 1px soild #999999;
}
.me-name{
  position: relative;
  left: 80upx;
  top: -28upx;
}
.icon-yezi{
  position: relative;
  top: -50upx;
  left: 80upx;
  color: rgb(135, 214, 16);
}
.icon-erweima{
  position: relative;
  top: 58upx;
  left: -30upx;
  float: right;
  font-size: 40upx;
  color: grey;
}
.me-all{
  height: 118upx;
  width: 100%;
  background-color:white;
  margin-top: 24upx;
}
.icon-gerenxinxi{
  float: left;
  font-size: 60upx;
  margin: 3% 30upx 0upx 45upx;
  color: rgb(51, 173, 255);
}
.me-xinxiall{
  float: left;
  margin-top: 5%;
}
.icon-jiantou{
  float: right;
  font-size: 50upx;
  margin:35upx 25upx 0upx 0upx;
}
.icon-xiaozu{
  float: left;
  font-size: 70upx;
  margin: 26upx 24upx 0upx 42upx;
  color: rgb(116, 173, 29);
}
.me-cover{
   height: 118upx;
  width: 100%;
  background-color:white;
  border-top: 1px solid rgb(243, 239, 239);
}
.icon-shuben{
  font-size: 64upx;
  margin: 26upx 24upx 0upx 46upx;
  color: #ca711d;
  float: left;
}
.icon-wenjuan{
  font-size: 64upx;
  margin: 26upx 24upx 0upx 46upx;
  color: rgb(1, 200, 171);
  float: left;
}
.icon-xinxi {
  font-size: 64upx;
  margin: 26upx 24upx 0upx 46upx;
  color: rgb(65, 163, 187);
  float: left;
}
.icon-shouce-{
  font-size: 76upx;
  margin: 20upx 16upx 0upx 40upx;
  color: rgb(65, 163, 187);
  float: left;
}
</style>
