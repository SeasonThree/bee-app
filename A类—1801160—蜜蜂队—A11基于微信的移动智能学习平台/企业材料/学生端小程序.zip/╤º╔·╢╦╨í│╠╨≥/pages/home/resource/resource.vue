<template>
	<view class="body-view">
		<view class="resource-search" style="border-top: 1px solid #E9E9E9;">
			<input class='resource-seach1' placeholder='搜索'></input>
			<icon class="iconfont icon-sousuo">&#xe61c;</icon>
		</view>
		<scroll-view class="top-menu-view" scroll-x="true" :scroll-left="scrollLeft">
			<block v-for="(menuTab,index) in menuTabs" :key="index">
				<view class="menu-one-view" v-bind:id="'tabNum'+index" @click="swichMenu(index)">
					<view :class="[currentTab==index ? 'menu-one-act' : 'menu-one']">
						<view class="menu-one-txt">{{menuTab.name}}</view>
						<view class="menu-one-bottom">
							<view class="menu-one-bottom-color"></view>
						</view>
					</view>
				</view>
			</block>
		</scroll-view>
		<view style="width: 100%;height: 20upx;background: rgb(245, 246, 248);">
		</view>
		<swiper :current="currentTab" class="swiper-box-list" duration="300" @change="swiperChange">
			<swiper-item>
				<scroll-view class="swiper-one-list" scroll-y="true">
					<image src="../../../static/images/resource-img.jpg" class="resource-img"></image>
					<image src="../../../static/images/resource-img1.jpg" class="resource-img"></image>
					<image src="../../../static/images/resource-img2.jpg" class="resource-img"></image>
				</scroll-view>
			</swiper-item>
			<swiper-item>
				<scroll-view class="swiper-one-list" scroll-y="true">
					<image src="../../../static/images/resource-bookimg.jpg" class="resource-img"></image>
					<image src="../../../static/images/resource-bookimg1.jpg" class="resource-img"></image>
				</scroll-view>
			</swiper-item>
			<swiper-item>
				<scroll-view class="swiper-one-list" scroll-y="true">
					<image src="../../../static/images/resource-magazineimg.jpg" class="resource-img"></image>
					<image src="../../../static/images/resource-magazineimg1.jpg" class="resource-img"></image>
				</scroll-view>
			</swiper-item>
		</swiper>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				scrollLeft: 0,
				isClickChange: false,
				currentTab: 0,
				menuTabs: [{
					name: '课程'
				},
				{
					name: '图书'
				},
				{
					name: '期刊'
				}
				],
				swiperDateList: [
					[],
					[]
				],
				questionlist:[{
					id:1,
					title:'Which one is the right answer',
					answer:[{
						type:'A',
						content:'apple'
					},
					{
						type:'B',
						content:'banana'
					},
					{
						type:'C',
						content:'orange'
					},
					{
						type:'D',
						content:'pear'
					}]
				},
				{
					id:2,
					title:'Which one is the right answer',
					answer:[{
						type:'A',
						content:'apple'
					},
					{
						type:'B',
						content:'banana'
					},
					{
						type:'C',
						content:'orange'
					},
					{
						type:'D',
						content:'pear'
					}]
				},
				{
					id:3,
					title:'Which one is the right answer',
					answer:[{
						type:'A',
						content:'apple'
					},
					{
						type:'B',
						content:'banana'
					},
					{
						type:'C',
						content:'orange'
					},
					{
						type:'D',
						content:'pear'
					}]
				}]
			}
		},
		onLoad: function() {
			//初始化数据
			for (var i = 0; i < this.swiperDateList.length; i++) {
				this.getDateList(i);
			}
		},
		methods: {
			swichMenu: async function(current) { //点击其中一个 menu
				if (this.currentTab == current) {
					return false;
				} else {
					this.currentTab = current;
					this.setScrollLeft(current);
				}
			},
			swiperChange: async function(e) {
				let index = e.target.current;
				this.setScrollLeft(index);
				this.currentTab = index;
			},
			setScrollLeft: async function(tabIndex) {
				let leftWidthSum = 0;
				for (var i = 0; i <= tabIndex; i++) {
					let nowElement = await this.getWidth('tabNum' + i);
					leftWidthSum = leftWidthSum + nowElement.width;
				}
				let winWidth = uni.getSystemInfoSync().windowWidth;
				this.scrollLeft = leftWidthSum > winWidth ? (leftWidthSum - winWidth) : 0
			},
			getWidth: function(id) { //得到元素的宽高
				return new Promise((res, rej) => {
					uni.createSelectorQuery().select("#" + id).fields({
						size: true,
						scrollOffset: true
					}, (data) => {
						res(data);
					}).exec();
				})
			},
			loadMore: function(tabIndex) {
				console.log('正在加载更多数据。。。')
				this.getDateList(tabIndex);
			},
			getDateList: function(tabIndex) {
				for (var i = 0; i < 20; i++) {
					var entity = this.menuTabs[tabIndex].name + (this.swiperDateList[tabIndex].length);
					this.swiperDateList[tabIndex].push(entity);
				}
			}

		}
	}
</script>

<style>
	.resource-img{
		height: 900upx;
		width: 100%;
	}
	.resource-search{
		height: 100upx;
		width: 100%;
		margin: auto;
	}
	.resource-seach1{
		z-index: 0;
		height: 60upx;
		width: 600upx;
		background-color: rgb(245, 246, 248);
		margin:auto;
		position: relative;
		top: 20upx;
		font-size:25upx; 
		border-radius: 40upx;
		text-align: center;
	}
	.resource-search .icon-sousuo{
		position: relative;
		left: 310upx;
		top: -52upx;
		z-index: 1;
	}
	page {
		width: 100%;
		height: 100%;
		display: flex;
		flex-wrap: wrap;
		align-items: flex-start;
		justify-content: center;
		
	}

	.body-view {
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
		width: 100%;
		align-items: flex-start;
		justify-content: center;
	}

	.top-menu-view {
		display: flex;
		white-space: nowrap;
		width: 100%;
		background: white;
		height: 60upx;
		border-bottom: 1px solid #E9E9E9;
		/* 在这里设置导航条高度 */
	}

	.top-menu-view .menu-one-view {
		display: inline-block;
		white-space: nowrap;
		height: 100%;

	}

	.top-menu-view .menu-one-view .menu-one {
		/* 在这里写未选中的单个按钮样式 */
		margin-left: 25upx;
		margin-right: 25upx;
		position: relative;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 200upx;
	}

	.top-menu-view .menu-one-view .menu-one .menu-one-txt {
		height: 40upx;
		font-size: 36upx;
		font-weight: 400;
		color: rgba(154, 154, 154, 1);
		line-height: 40upx;
	}

	.top-menu-view .menu-one-view .menu-one .menu-one-bottom {
		position: absolute;
		bottom: 0;
		width: 100%;
	}

	.top-menu-view .menu-one-view .menu-one .menu-one-bottom .menu-one-bottom-color {
		width: 100%;
		height: 4upx;
	}

	.top-menu-view .menu-one-view .menu-one-act {
		/* 在这里写选中后的单个按钮样式 */
		margin-left: 25upx;
		margin-right: 25upx;
		position: relative;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 200upx;
	}

	.top-menu-view .menu-one-view .menu-one-act .menu-one-txt {
		height: 40upx;
		font-size: 36upx;
		font-weight: 400;
		color: rgba(0, 170, 255, 1);
		line-height: 40upx;
	}

	.top-menu-view .menu-one-view .menu-one-act .menu-one-bottom {
		position: absolute;
		bottom: 0;
		width: 100%;
		display: flex;
		justify-content: center;
	}

	.top-menu-view .menu-one-view .menu-one-act .menu-one-bottom .menu-one-bottom-color {
		width: 100upx;
		height: 4upx;
		background: rgba(0, 170, 255, 1);
	}

	.swiper-box-list {
		flex: 1;
		width: 100%;
		height: auto;
		background: rgba(244, 245, 247, 1);
	}

	.swiper-one-list {
		height: 100%;
		width: 100%;
	}

	.swiper-one-list .swiper-list-entity {
		width: 100%;
		height: 112upx;
		text-align: center;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		justify-content: center;
	}

	.panel {
		width: 100%;
		display: flex;
		flex-direction: column;
		padding: 40upx 30upx;
		background: white;

	}

	.panel-head {
		font-size: 34upx;
		color: grey;
	}

	.panel-body {
		font-size: 30upx;
		color: black;
		padding-right: 20upx;
	}

	.panel image {
		width: 92%;
	}

	.status {

		background: red;
		display: inline-block;
		width: 30upx;
		height: 30upx;
		border-radius: 50%;
		margin-right: 20upx;
	}

	.border {
		width: 100%;
		height: 2upx;
		background: lightgrey;
		margin: 20upx 0;
	}

	.question,
	.test-head,
	.panel-head {
		background: white;
	}
</style>
