<template>
	<view class='class-container'>
  <view class='class-top'>
    <text class='class-bigtitle'>第13周</text>
    <text class='class-title'>大二 第1学期</text>
    <text class='class-change'>修改</text>
  </view>
  <view class='class-colums'>
    <text class='class-num'>12月</text>
    <text class='class-number'>1</text>
    <text class='class-number'>2</text>
    <text class='class-number'>3</text>
    <text class='class-number'>4</text>
    <text class='class-number'>5</text>
    <text class='class-number'>6</text>
    <text class='class-number'>7</text>
    <text class='class-number'>8</text>
    <text class='class-number'>9</text>
    <text class='class-number'>10</text>
    <text class='class-number'>11</text>
    <text class='class-number'>12</text>
  </view>
  <view class='class-row'>
    <text class='class-day'>周一</text>
	<text class='class-day'>周二</text>
	<text class='class-day'>周三</text>
	<text class='class-day'>周四</text>
	<text class='class-day class-diff'>周五</text>
	<text class='class-day'>周六</text>
	<text class='class-day'>周日</text>
    <view class='class-day1'>
		<text class='class-day'>03号</text>
		<text class='class-day'>04号</text>
		<text class='class-day'>05号</text>
		<text class='class-day'>06号</text>
		<text class='class-day class-diff'>07号</text>
		<text class='class-day'>08号</text>
		<text class='class-day'>09号</text>
	</view>
  </view>
  <view class='class-border'>
    <text style="display: block;">大学英语（3）</text>
		<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class='class-border' style='background-color:rgb(249, 222, 91);'>
    <text style="display: block;">C语言基础</text>
		<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class='class-border' style='background-color:rgb(89, 240, 163);'>
    <text style="display: block;">大学语文</text>
		<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class='class-border' style='background-color:rgb(213, 141, 251);'>
    <text style="display: block;">数据结构</text>
		<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class="class-inrow">
    <view class='class-border' style='background-color:rgb(134, 175, 254);'>
      <text style="display: block;">大学语文</text>
			<text style="font-size: 14px;">@xx楼xx-xxx</text>
   </view>
    <view class='class-border' style='background-color:rgb(130, 208, 249);'>
      <text style="display: block;">高等数学</text>
	  <text style="font-size: 14px;">@xx楼xx-xxx</text>
   </view>
  </view>
  <view class='class-inrow1'>
    <view class='class-border' style='background-color:rgb(255, 147, 147);'>
    <text style="display: block;">大学物理（1）</text>
	<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class='class-border ' style='background-color:rgb(255, 157, 215);'>
    <text style="display: block;">数据结构</text>
	<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  </view>
  <view class='class-inrow1' style='float:left;'>
    <view class='class-border' style='background-color:rgb(171, 145, 255);'>
    <text style="display: block;">茶道品析</text>
	<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class='class-border ' style='background-color:rgb134, 175, 254);'>
    <text style="display: block;">手工艺术</text>
	<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  <view class='class-border' style='background-color:rgb(89, 240, 163);'>
    <text style="display: block;">高等数学</text>
	<text style="font-size: 14px;">@xx楼xx-xxx</text>
  </view>
  </view>
</view>

</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
	.class-container{
  height: 740px;
  width: 100%;
}
.class-top{
  height: 120upx;
  width: 100%;
  background-color: white;
  
  padding-top: 24upx;
}
.class-colums{
  height: 1400upx;
  width: 10%;
  background-color: rgb(244, 248, 249);
  float: left;
}
.class-row{
  height: 100upx;
  width: 90%;
 float: left;
 padding-top: 16upx;
 background-color:rgb(244, 248, 249);
}
.class-bigtitle{
  font-size: 40upx;
  margin-left: 300upx;
  display: block;
}
.class-title{
  position: relative;
  top: 14upx;
  left: 274upx;
  font-size: 32upx;
  color: gray;
}
.class-change{
  float: right;
  position: relative;
  top: -48upx;
  left: -30upx;
  border: 1px solid rgb(56, 166, 218);
  border-radius: 30px;
  padding: 2px 10px;
  color: rgb(56, 166, 218);
}

.class-day{
  margin: 0upx 16upx;
  font-size: 16px;
}
.class-day1 .class-day{
  position: relative;
  top: 16upx;
  margin: 0upx 15upx 0upx 20upx;
  font-size: 30upx;
  color: grey;
}
.class-day1 .class-diff, .class-diff{
  color:  rgb(58, 97, 224);
}
.class-num{
  display: block;
  padding: 22upx 0upx 22upx 18upx;
  font-size: 32upx;
}
.class-number{
  display: block;
  padding: 30upx 0upx 38upx 26upx;
  font-size: 32upx;
}
.class-border{
  float: left;
  height: 188upx;
  width: 92upx;
  background-color: rgb(140, 140, 240);
  border-radius: 15upx;
  font-size: 32upx;
  font-weight: 500;
  text-align: center;
  padding-top: 14upx;
  color: white;
  margin:4upx 4upx 4upx 4upx;
}
.class-inrow{
  height: 184upx;
  width:  90%;  
  float: left;
}
.class-inrow1{
  height: 184upx;
  width:  52%;  
  float: right;
  margin-top: 22upx;
}
</style>
