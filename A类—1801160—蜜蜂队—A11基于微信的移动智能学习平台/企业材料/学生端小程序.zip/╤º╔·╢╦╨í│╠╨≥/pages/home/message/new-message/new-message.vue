<template>
	<view class="container">
		<input placeholder="消息标题" />

		<textarea placeholder="内容"></textarea>

		<view>
			<view>附件（可选）</view>
			<view style="width: 710upx;padding: 10upx;text-align: center;background: white;height: 50upx;line-height: 50upx;">上传附件</view>
			<view>收信人</view>
			<view><radio></radio>全选</view>
			</view>
			<view class="student-list padding-sm">
		

			<block v-for="(student,index) in studentlist" :key="index">
				<view class="student-list-item padding-sm">
					<radio></radio>
					<image class="avatar" :src="student.avatar">

					</image>
					<view class="student-info padding-sm">
						<view class="name">{{student.name}}</view>


					</view>

				</view>

			</block>
		</view>
		<view class="buttons">
			<view class="b1" size="default">保存至草稿箱</view>
			<view class="b2" size='default'>立即发送</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				studentlist: [{
						avatar: '/static/images/jianshang.jpg',
						name: '楚若黎',
						id: '2017082312'
					},
					{
						avatar: '/static/images/mama.jpg',
						name: '顾润之',
						id: '2017082313'
					},
					{
						avatar: '/static/images/lishi.jpg',
						name: '楚秋然',
						id: '2017082314'
					},
					{
						avatar: '/static/images/xinli.jpg',
						name: '愧泽',
						id: '2017082315'
					}
				],

			};
		}
	}
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	input {
		width: 710upx;
		height: 50upx;
		padding: 10upx;
		margin: 10upx 0;
		background: white;
	}

	textarea {
		width: 710upx;
		padding: 10upx;
		margin: 10upx 0;
		background: white;
	}

	.student-list {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: space-between;
	}

	.student-list-item {
		width: 300upx;
		display: flex;
		background: white;
		justify-content: space-between;
		align-items: center;
		margin: 5upx;
	}

	.avatar {
		width: 70upx;
		height: 70upx;

		border: thin solid grey;
		padding: 5upx;
		border-radius: 5upx;
		position: relative;
	}

	.student-info {
		position: relative;
		width: 130upx;
	}

	.buttons {
		width: 750upx;
		display: flex;
		flex-direction: row;
		justify-content: space-around;
		position: fixed;
		bottom: 200upx;
	}

	.b1 {
		width: 280upx;
		height: 60upx;
		background: white;
		border: thin solid rgb(0, 153, 255);
		color: rgb(0, 153, 255);
		text-align: center;
		line-height: 60upx;
		padding: 15upx;
		border-radius: 15upx;
	}

	.b2 {
		width: 280upx;
		height: 60upx;
		border: thin solid rgb(0, 153, 255);
		background: rgb(0, 153, 255);
		color: white;
		text-align: center;
		line-height: 60upx;
		padding: 15upx;
		border-radius: 15upx;
	}
</style>
