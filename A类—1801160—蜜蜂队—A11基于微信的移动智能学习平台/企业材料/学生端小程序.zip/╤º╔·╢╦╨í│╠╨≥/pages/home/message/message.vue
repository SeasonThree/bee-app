<template>
	<view class="container padding-md">
		
		

		<view class="page">
			<view class="head">
				<segmented-control :values="items" v-on:clickItem="onClickItem" :styleType="styleType" :activeColor="activeColor"
				 style='width: 60upx;'></segmented-control>
			</view>
			<view class="content">
				<view v-show="current === 0" class="padding-sm">
					<view class="panel padding-md margin">
							<block v-for="(item,index) in itemlist" :key="index">
								<view class="item-list-item padding-sm" @click="goDetailPages(item.name)">
									<view class="avatar">
										消息
									</view>
									<view class="item-info padding-sm">
										<view class="type">[{{item.type}}]</view>
										<view class="item-status font-xs grey">{{item.status}}</view>
						
									</view>
									<text class="time">
										<text class="up">
											{{item.year}}  {{item.day}}
										</text>
										<text class="down">
											{{item.clock}}
										</text>
									</text>
								</view>
								<view class="border"></view>
							</block>
						
						
					</view>
				</view>
				<view v-show="current === 1" class="padding-sm">
					<page-head :title="title"></page-head>
					<view class="panel padding-md margin">
						<view>
					暂无发送过的消息
						</view>
						
					</view>
				</view>
				<view v-show="current === 2" class="padding-sm">
					<page-head :title="title"></page-head>
					<view class="panel padding-md margin">
						<view>
						暂无草稿
						</view>
						
					</view>
				</view>
			</view>
		</view>
		<view class="button">
			<button @click="goDetailPage()">新建消息</button>
		</view>
	</view>

</template>

<script>
	import segmentedControl from '@/components/uni-segmented-control.vue';
	export default {
		data() {
			return {
				items: [
					'收信箱',
					'发信箱',
					'草稿箱'
					
				],
				styles: [{
					value: 'button',
					text: '按钮',
					checked: true
				}, {
					value: 'text',
					text: '文字'
				}],
				colors: [
					'#007aff',
					'#4cd964',
					'#dd524d'
				],
				current: 0,
				activeColor: '#0099FF',
				styleType: 'button',
				itemlist: [{
							type: '王老师',
							status: '已读',
				
							year: '2018-12-03',
							day: '星期二',
							clock: '20:21:10'
				
						
					},
					{
							type: '李老师',
							status: '已读',
					
							year: '2018-12-04',
							day: '星期二',
							clock: '10:22:10'
					
						
					},
					{
							type: '章一',
							status: '已读',
					
							year: '2018-12-05',
							day: '星期四',
							clock: '8:21:10'
					
						
					}
				]
		};
	},
		methods: {

			goDetailPage() {
				
					uni.navigateTo({
						url: 'new-message/new-message'
					})
				
			
			},
			goDetailPages(e) {
				
					uni.navigateTo({
						url: 'detail/detail'
					})
				
			
			},
			onClickItem(index) {
				if (this.current !== index) {
					this.current = index;
				}
			},
			styleChange(evt) {
				if (this.styleType !== evt.target.value) {
					this.styleType = evt.target.value;
				}
			},
			colorChange(evt) {
				if (this.styleType !== evt.target.value) {
					this.activeColor = evt.target.value;
				}
			},
			
			
		},
		
		components: {
			segmentedControl
		}
	
	}
</script>

<style>
	.container{
		width: 710upx;
	}
	.course-info {
		background: rgb(0, 153, 255);
		color: white;
	}

	.item-list-item {
		display: flex;
		background: white;
		justify-content: space-between;
		align-items: center;
	}

	.button {
		
		display: flex;
		justify-content: center;
	}

	button {
		width: 400upx;
		height: 80upx;
		background: #0099FF;
		color: white;
		border-radius: 10upx;
		line-height: 80upx;
		font-size: 34upx;
	}

	.avatar {
		width: 70upx;
		height: 70upx;
		background: #0099FF;
		border: thin solid grey;
		padding: 5upx;
		border-radius: 5upx;
		color: white;
		line-height: 70upx;
		
		text-align: center;
	}

	.item-info {
		position: relative;
		left: -70upx;
	}
.type{
	color:rgb(255, 114, 152) ;
}
.status{
	color: lightgrey;
}
	.border {
		width: 100%;
		height: 4upx;
		background: lightgrey;
	}

	.time {
		margin-right: 20upx;
		
		font-size: 26upx;
		font-weight: 600;
		width: 240upx;
		display: flex;
		flex-direction: column;
	}
	.down{
		display: flex;
		justify-content: center;
		color: grey;
	}
	page{
		background: rgb(245, 246, 248);
		font-size: 30upx;
	}
		.head {
			padding: 0 20upx;
			margin-top: 20upx;
			height: 100upx;
		}
	
	
		.segmented-control {
			width: 80%;
		}
	
		.content {
			display: flex;
			justify-content: center;
			align-items: center;
			text-align: center;
		}
	
		
	.margin{
		margin-bottom: 50upx;
	}
		.text {
			display: flex;
			flex-direction: row;
			justify-content: space-around;
			padding: 40upx;
			align-self: flex-end;
		}
	
		.pull-right {
			margin-left: 460upx;
		}
	
		.color-tag {
			width: 50upx;
			height: 50upx;
		}
	
		.panel {
			width: 750upx;
			min-height: 300upx;
			
			margin: 40upx 0 80upx 0;
			display: flex;
		flex-direction: column
		}
</style>
