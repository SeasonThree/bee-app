<template>
	<view class="container">
		<view class="sender padding-sm font-lg">李老师</view>
		
		<view class="body">
			<view class="title padding-sm font-md">问候</view>
			<view class="time font-sm padding-sm">2019/02/23 11:09</view>
			<view class="border"></view>
			<view class="content padding-sm font-md">今天天气真好</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
.sender{
	width: 710upx;
	background: white;
	margin: 20upx 0;
}
.time{
	color: grey;
	
}
.content{
	width: 710upx;
	height: 400upx;
	
}
.body{
	background: white;
}
.border{
	width: 730upx;
	height: 2upx;
	margin: 10upx auto;
	background: #C8C7CC;

}
</style>
