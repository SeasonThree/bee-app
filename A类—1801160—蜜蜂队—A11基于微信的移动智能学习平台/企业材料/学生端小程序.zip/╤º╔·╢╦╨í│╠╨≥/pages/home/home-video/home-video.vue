<template>
	<view class="container">
		<view class="video-search" style="border-top: 1px solid #E9E9E9;">
			<input class='video-seach1' placeholder='搜索' type="text" confirm-type="search" @input="switchTo"></input>
			<icon class="iconfont icon-sousuo" :style="{display:activeDisplay}">&#xe61c;</icon>
		</view>
		<view :style="{display:anotherDisplay}" style="width: 100%;">
			
			<block v-for="(item, index) in items" :key="index">
				<view class="hideVideo" @tap="linkTo">
					<view style="width: 25%;height: 100%;" class="video-left">
						<image :src="item.image" class="video-img"></image>
						<text style="margin-top:10upx;font-size: 28upx;">XXX老师</text>
					</view>
					<view style="width: 50%;height: 100%;float: left;" >
						<text style="font-size: 20px;float: left;margin-top: 20upx;margin-left: 15upx;">高等数学</text>
						<text style="font-size: 15px;margin-top: 20upx;float: left;color: rgb(83, 85, 85);margin-left: 15upx;">2018学年第一学期</text>
						<text style="font-size: 15px;margin-top: 15upx;float: left;color: blue;margin-left: 15upx;">
							XXX大学
						</text>
					</view>
					<view style="width: 25%;height: 100%;" class="video-left">
						<image src="../../../static/images/QR_code.jpg" style="height: 120upx;width: 120upx;"></image>
						<text style="font-size: 30upx;">{{item.title}}</text>
					</view>
				</view>
			</block>
			
		</view>
		<view :style="{display:activeDisplay}">
			
			<view class="live-item">
				<view class="tips">
					<text style="margin-left: 20upx;">
						推荐视频
					</text>
					<view  class="refresh">
						<image  src="/static/images/refresh.png" style="float: left;margin: 4upx;"></image>
						换一换
					</view>
				</view>
				<view class="recommendation">
					
					<block v-for="(item,index) in live" :key="index">
						<view class="recommendation-item">
							<view class="video">
								<image :src="item.image" class="picture" mode="aspectFit"></image>
							</view>
							<view class="title">
								{{item.title}}
							</view>
						</view>
					</block>
				</view>
			</view>
			
				<view class="live-item">
				<view class="tips">
					<text style="margin-left: 20upx;">
						推荐视频
					</text>
					<view  class="refresh">
						<image  src="/static/images/refresh.png" style="float: left;margin: 4upx;"></image>
						换一换
					</view>
				</view>
				<view class="recommendation">
					
					<block v-for="(item,index) in recommendation" :key="index">
						<view class="recommendation-item">
							<view class="video">
								<image :src="item.image" class="picture" mode="aspectFit"></image>
							</view>
							<view class="title">
								{{item.title}}
							</view>
						</view>
					</block>
				</view>
			</view>
			
				<view class="live-item">
				<view class="tips">
					<text style="margin-left: 20upx;">
						推荐视频
					</text>
					<view  class="refresh">
						<image  src="/static/images/refresh.png" style="float: left;margin: 4upx;"></image>
						换一换
					</view>
				</view>
				<view class="recommendation">
					
					<block v-for="(item,index) in review" :key="index">
						<view class="recommendation-item">
							<view class="video">
								<image :src="item.image" class="picture" mode="aspectFit"></image>
							</view>
							<view class="title">
								{{item.title}}
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				anotherDisplay:"none",
				activeDisplay:"block",
				inputValue:"",
				hasInputValue:"高等数学",
				items:[
					{
						image:'/static/images/avatar.jpeg',
						title:'uf17124'
					},
					{
						image:'/static/images/jianshang.jpg',
						title:'ay25846'
					}
					],
				recommendation:[
					{
						image:'/static/images/Snipaste_2019-01-19_11-01-15.png',
						title:'java 从入门到精通'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-00-44.png',
						title:'java 从入门到精通'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-01-15.png',
						title:'java 从入门到精通'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-00-44.png',
						title:'java 从入门到精通'
					}
				],
				live:[
					{
						image:'/static/images/Snipaste_2019-01-19_11-00-44.png',
						title:'php 从入门到精通'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-01-15.png',
						title:'C 从入门到精通'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-00-44.png',
						title:'C++ 从入门到精通'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-01-15.png',
						title:'C## 从入门到精通'
					}
				],
				review:[
					{
						image:'/static/images/Snipaste_2019-01-19_11-01-15.png',
						title:'科幻电影赏析'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-00-44.png',
						title:'英语音乐鉴赏'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-00-44.png',
						title:'《枪炮、病菌与钢铁》讨论'
					},
					{
						image:'/static/images/Snipaste_2019-01-19_11-01-15.png',
						title:'《他和她的故事》镜头语言分析'
					}
				]
			};
		},
		methods:{
			switchTo:function(event){
				this.inputValue = event.target.value;
				if(this.inputValue=='高等数学')
				{
					this.activeDisplay="none";
					this.anotherDisplay="block"
				}
				else if(this.inputValue=='')
				{
					this.activeDisplay="block";
					this.anotherDisplay="none"
				}
				else
				{
					this.activeDisplay="none";
					this.anotherDisplay="none"
				}
					
			},
			linkTo:function(){
				uni.navigateTo({
					url:'/pages/home/home-video/start-video/start-video'
				})
			}
		}
	}
</script>

<style>
	.container{
		display: flex;
		flex-direction: column;
		align-items: center;
		}
		.video-search{
			height: 100upx;
			width: 100%;
			margin: 0px auto;
			
		}
		.video-seach1{
			z-index: 0;
			height: 60upx;
			width: 600upx;
			background-color: white;
			margin: 0px auto;
			position: relative;
			top: 20upx;
			font-size:30upx; 
			border-radius: 40upx;
			text-align: center;
		}
		.video-search .icon-sousuo{
			position: relative;
			left: 310upx;
			top: -52upx;
			z-index: 1;
		}
	.live-item{
		margin: 20upx 0;
		height: 600upx;
	}
	.recommendation{
		width: 710upx;
		height: 450upx;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		flex-wrap: wrap;
		padding: 10upx;
	}
	.tips{
		width: 710upx;
		padding: 10upx;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
	}
	.refresh{
		color: grey;
		font-size: 30upx;
		margin-right: 20upx;
		margin-top: 6upx;
	}
	.recommendation-item{
		width: 320upx;
		
		text-align: center;
		padding: 10upx;
	}
	.picture{
		width: 100%;
		height: 180upx;
		width: 100%;
		
		
		border-radius: 20upx;
	}
	image{
		width: 30upx;
		height: 30upx;
	}
	.float_button{
		width: 150upx;
		height: 150upx;
		border-radius: 50%;
		background: #EAAC52;
		color: white;
		position: fixed;
		bottom: 200upx;
		right: 20upx;
		text-align: center;
		line-height: 150upx;
	}
	.video-left{
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		float: left;
	}
	.video-img{
		width: 100upx;
		height: 100upx;
		border-radius: 50upx;
	}
	.hideVideo{
		width: 100%;
		height: 200upx;
		background:rgb(247, 241, 241);
		border: 1px solid #E9E9E9;
	}
</style>
