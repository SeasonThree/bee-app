<template>
	<view style="background: rgb(245, 246, 248);height: 2000upx;">
		<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" style="height: 320upx;">
			<swiper-item>
				<view class="swiper-item"><image src="../../static/images/3.jpg" style="width: 100%;"></image></view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item"><image src="../../static/images/4.jpg" style="width: 100%;"></image></view>
			</swiper-item>
			<swiper-item>
				<view class="swiper-item"><image src="../../static/images/11.jpg" style="width: 100%;"></image></view>
			</swiper-item>
		</swiper>
		
		<view class="home-top">
			<view class="hometop-apart" @tap="linkto" data-name="school-timetable">
				<text class="iconfont kebiao">&#xe612;</text>
				<text style="font-size: 34upx;color: grey;">课表</text>
			</view>
			<view class="hometop-apart" @tap="linkto" data-name="resource">
				<text class="iconfont ziyuan">&#xe60b;</text>
				<text style="font-size: 34upx;color: grey;">资源</text>
			</view>
			<view class="hometop-apart" @tap="linkto" data-name="home-video">
				<text class="iconfont zhibo">&#xe626;</text>
				<text style="font-size: 34upx;color: grey;">直播</text>
			</view>
			<view class="hometop-apart" @tap="linkto" data-name="message">
				<text class="iconfont xiaoxi">&#xe695;</text>
				<text style="font-size: 34upx;color: grey;">消息</text>
			</view>
		</view>
		
		<view class="home-class">
			<view class="homeclass-top">
				<text class="hctop-text1">Friday</text>
				<text style="margin-left: 40upx; font-size: 36upx;">第12周</text>
				<text class="hctop-text2">今天有4节课</text>
			</view>
			<view class="homeclass-contant">
				<view class="contant-first">
					<text style="color: rgb(130, 128, 152);margin-left: 40upx;font-size: 40upx;">1-2</text>
				</view>
				<view>
					<text style="font-size: 42upx;display: block;">大学英语（3）</text>
					<icon class="iconfont" style="float: left;margin: 6upx;">&#xe600;</icon>
					<text style="float: left;margin-top: 24upx;font-size: 30upx;color: rgb(130, 128, 152);">32号楼32-505</text>	
				</view>
			</view>
			<view class="border"></view>
			<view class="homeclass-contant" style="padding-top: 30upx;">
				<view class="contant-first">
					<text style="color: rgb(130, 128, 152);margin-left: 40upx;font-size: 40upx;">1-2</text>
				</view>
				<view>
					<text style="font-size: 42upx;display: block;">高等数学</text>
					<icon class="iconfont" style="float: left;margin: 6upx;">&#xe600;</icon>
					<text style="float: left;margin-top: 24upx;font-size: 30upx;color: rgb(130, 128, 152);">32号楼32-505</text>	
				</view>
			</view>
			<view class="border"></view>
			<view class="homeclass-contant" style="padding-top: 30upx;">
				<view class="contant-first">
					<text style="color: rgb(130, 128, 152);margin-left: 40upx;font-size: 40upx;">1-2</text>
				</view>
				<view>
					<text style="font-size: 42upx;display: block;">茶道品析</text>
					<icon class="iconfont" style="float: left;margin: 6upx;">&#xe600;</icon>
					<text style="float: left;margin-top: 24upx;font-size: 30upx;color: rgb(130, 128, 152);">32号楼32-505</text>	
				</view>
			</view>
			<view class="border"></view>
			<view class="homeclass-contant" style="padding-top: 30upx;">
				<view class="contant-first">
					<text style="color: rgb(130, 128, 152);margin-left: 40upx;font-size: 40upx;">1-2</text>
				</view>
				<view>
					<text style="font-size: 42upx;display: block;">数据结构</text>
					<icon class="iconfont" style="float: left;margin: 6upx;">&#xe600;</icon>
					<text style="float: left;margin-top: 24upx;font-size: 30upx;color: rgb(130, 128, 152);">32号楼32-505</text>	
				</view>
			</view>
			<view class="border"></view>
		</view>
		
		<view class="home-tuijian">
			<view class='padding-sm' style="margin-bottom: 4upx;">
				<text class='font-sm' style="margin-left: 15upx;">推荐课程</text>
				<text class='pull-right font-sm' style='color:#0099FF;margin-right: 16upx;'>更多>></text>
			</view>
			<view class="tuijian-contant">
				<view class="tuijian-apart">
					<image src="../../static/images/Snipaste_2019-01-19_11-00-44.png" class="tuijian-img"></image>
					<text style="display: block;">极简信息技术</text>
					<text style="font-size: 26upx;float: right;margin: 20upx 40upx 0upx 0upx;color: grey">48小节 32k人参与</text>
				</view>
				<view class="tuijian-apart">
					<image src="../../static/images/Snipaste_2019-01-19_11-01-15.png" class="tuijian-img"></image>
					<text style="display: block;">《论语》自我提升</text>
					<text style="font-size: 26upx;float: right;margin: 20upx 40upx 0upx 0upx;color: grey">48小节 32k人参与</text>
				</view>
				<view class="tuijian-apart">
					<image src="../../static/images/cyuyan.jpg" class="tuijian-img"></image>
					<text style="display: block;">C语言程序设计</text>
					<text style="font-size: 26upx;float: right;margin: 20upx 40upx 0upx 0upx;color: grey">48小节 32k人参与</text>
				</view>
				<view class="tuijian-apart">
					<image src="../../static/images/biology.jpg" class="tuijian-img"></image>
					<text style="display: block;">药物分析与制作</text>
					<text style="font-size: 26upx;float: right;margin: 20upx 40upx 0upx 0upx;color: grey">48小节 32k人参与</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			linkto:function(event){
				var functionsName = event.currentTarget.dataset.name
				
				uni.navigateTo({
					url:"/pages/home/"+functionsName+"/"+functionsName
				})
			}
		},
		onShow() {
			getApp().gloabalData=undefined
		}
	}
</script>

<style>
	.pull-right{
	  float: right;
	}
	.pull-left{
	  float:left;
	}
	.home-top{
		height: 170upx;
		width: 100%;
		display: flex;
		flex-direction: row;
		background: white;
	}
	.hometop-apart{
		width: 25%;
		height: 100%;
		text-align: center;
	}
	.kebiao{
		font-size: 60upx;
		display: block;
		margin-top: 26upx;
		margin-bottom: 12upx;
		color: rgb(51, 198, 138);
	}
	.ziyuan{
		font-size: 74upx;
		display: block;
		margin-top: 21upx;
		margin-bottom: 3upx;
		color: rgb(255, 193, 3);
	}
	.xiaoxi{
		font-size: 60upx;
		display: block;
		margin-top: 25upx;
		margin-bottom: 11upx;
		color: rgb(67, 168, 108);
	}	
	.zhibo{
		font-size: 60upx;
		display: block;
		margin-top: 24upx;
		margin-bottom: 13upx;
		color: rgb(255, 91, 137);
	}
	.home-class{
		margin-top: 30upx;
		height: 910upx;
		width: 100%;
		background: white;
	}
	.homeclass-top{
		height: 160upx;
		width: 100%;
		float: left;
	}
	.hctop-text1{
		display: block;
		font-size: 60upx;
		font-weight: bold;
		margin: 20upx 0upx 10upx 40upx;
	}
	.hctop-text2{
		float: right;
		font-size: 12px;
		border: 1px solid rgb(211, 211, 211);
		border-radius: 40upx;
		padding: 2px 20upx;
		position: relative;
		left: -20px;
		top:-1px;
	}
	.homeclass-contant{
		float: left;
		height: 130upx;
		width: 100%;
		display: flex;
		flex-direction: row;
	}
	.contant-first{
		height: 100%;
		width: 150upx;
	}
	.border{
		background: rgb(235, 233, 233);
		width: 86%;
		height:1px;
		margin: 5px 7%;
		float: left;
	}
	.home-tuijian{
		height: 760upx;
		width: 100%;
		background: white;
		margin-top: 30upx;
	}
	.tuijian-contant{
		height: 700upx;
		width: 100%;
	}
	.tuijian-apart{
		width: 50%;
		height: 50%;
		text-align: center;
		float: left;
	}
	.tuijian-title{
		height: 60upx;
		width: 100%;
	}
	.tuijian-img{
		height: 60%;
		width: 86%;
		margin: 10upx 7%;
	}
</style>
