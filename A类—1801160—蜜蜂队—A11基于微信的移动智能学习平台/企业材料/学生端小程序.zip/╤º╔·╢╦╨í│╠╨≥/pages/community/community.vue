<template>
	<view>
		<view class="community-top">
			<span class="iconfont paizhao">&#xe608;</span>
			<image src="../../static/images/katong_longmao-003.jpg" style="height: 500upx;width: 100%;"></image>
			<image src="../../static/images/me.jpg" class="comtop-img"></image>
			<text style="float: right;position: relative;right: 40upx;top: -60upx;color: white;">顾润之</text>
		</view>	
		<view class="community-content">
			<view style="height: 110upx;width: 100%;">
				<image src="../../static/images/me.jpg" class="content-title"></image>
				<text style="float: left;margin-top: 10upx;font-size: 17px;color: rgb(122, 140, 243);">顾润之</text>
			</view>
			<view style="height: 500upx;width: 100%;">
				<text class="content-text">有一美人兮，见之不忘。 
					  一日不见兮，思之如狂。 
					  凤飞翱翔兮，四海求凰。 
					  无奈佳人兮，不在东墙。 
					  将琴代语兮，聊写衷肠。 
					  何日见许兮，慰我彷徨。 
					  愿言配德兮，携手相将。 
					  不得於飞兮，使我沦亡。 
					  凤兮凤兮归故乡，遨游四海求其凰。
				</text>
			</view>
			<view style="height: 90upx;width: 100%;display: flex;flex-direction: row;border-bottom: 1px solid rgb(247, 241, 241);">
				<view style="height: 100%;width: 33%;">
					<span class="iconfont liaotian">&#xe6b7;</span>
					<text style="float: left;margin:13% 0px 0px 0px;font-size: 16px;">112</text>
				</view>
				<view style="height: 100%;width: 33%;">
					<span class="iconfont liaotian" :class="{newchange:isfalse}" style="margin: 8% 3% 0px 25%;" @tap="linkto">&#xe604;</span>
					<text style="float: left;margin:13% 0px 0px 0px;font-size: 16px;">{{text}}</text>
				</view>
				<view style="height: 100%;width: 33%;" >
					<span class="iconfont liaotian">&#xe936;</span>
					<text style="float: left;margin:13% 0px 0px 0px;font-size: 16px;">转发</text>
				</view>
			</view>
		</view>
		<view class="community-content" style="height: 730upx;margin-top: 40upx;">
			<view style="height: 110upx;width: 100%;">
				<image src="../../static/images/me.jpg" class="content-title"></image>
				<text style="float: left;margin-top: 10upx;font-size: 17px;color: rgb(122, 140, 243);">顾润之</text>
			</view>
			<view style="height: 530upx;width: 100%;">
				<text class="content-text">
					春江潮水连海平，海上明月共潮生。 
					滟滟随波千万里，何处春江无月明！ 
					江流宛转绕芳甸，月照花林皆似霰。
				</text>
				<image src="../../static/images/mmexport1515926688759.jpg" style="height: 60%;width: 50%;margin-left: 19%;"></image>
			</view>
			<view style="height: 90upx;width: 100%;display: flex;flex-direction: row;">
				<view style="height: 100%;width: 33%;">
					<span class="iconfont liaotian">&#xe6b7;</span>
					<text style="float: left;margin:13% 0px 0px 0px;font-size: 16px;">112</text>
				</view>
				<view style="height: 100%;width: 33%;">
					<span class="iconfont liaotian" style="margin: 8% 3% 0px 25%;" >&#xe604;</span>
					<text style="float: left;margin:13% 0px 0px 0px;font-size: 16px;">666</text>
				</view>
				<view style="height: 100%;width: 33%;">
					<span class="iconfont liaotian">&#xe936;</span>
					<text style="float: left;margin:13% 0px 0px 0px;font-size: 16px;">转发</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isfalse:false,
				text:"666"
			};
		},
		methods:{
			linkto:function(){
				this.text="667";
				this.isfalse=true;
			}
		},
		onShow() {
			getApp().gloabalData=undefined
		}
	}
</script>

<style>
	
	.liaotian{
		float: left;
		font-size: 50upx;
		margin: 9% 3% 0px 25%;
	}
	.newchange{
		color: red;
	}
	.content-text{
		line-height: 60upx;
		position: relative;
		left: 142upx;
		top: -40upx;
		font-size: 17px;
	}
	.content-title{
		height: 100upx;
		width: 100upx;
		border-radius: 10upx;
		float: left;
		margin: 10upx 20upx 0upx 26upx;
	}
	.community-content{
		margin-top: 80upx;
		float: left;
		height: 700upx;
		width: 100%;
	}
	.comtop-img{
		height: 170upx;
		width: 170upx;
		float: right;
		position: relative;
		top: -120upx;
		right: 24upx;
		border-radius: 10upx;
		border: 1px solid #E9E9E9;
	}
	.paizhao{
		font-size: 60upx;
		position: absolute;
		margin-left: 90%;
		color: white;
		
	}
	.community-top{
		float: right;
		height: 500upx;
		width: 100%;
	}
</style>
