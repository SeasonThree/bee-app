<template>
	<view>
		<view :style="{display:activeDisplay}">
			<view class="empower-top">
				<image src="../../static/images/me.jpg" class="empower-img"></image>
			</view>
			<view style="width: 80%;float: left;margin: 0upx 10%;border: 1px solid #EEEEEE;">
			</view>
			<view class="empower-body">
				<text style="display: block;margin-bottom: 30upx;">申请获取以下权限</text>
				<text style="color: #9D9D9D;">获得你的公开信息（昵称，头像等）</text>
			</view>
			<view style="width: 80%;margin: 0upx 10% ;">
				<button type="primary" style="border-radius: 100upx;" @tap="homeTo">授权登录</button>
			</view>
		</view>
		<!-- //主页出现 -->
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				activeDisplay:'block',
				anotherDisplay:'none',
			};
		},
		methods:{
			linkto:function(event){
				var functionsName = event.currentTarget.dataset.name
				
				uni.navigateTo({
					url:"/pages/home/"+functionsName+"/"+functionsName
				})
			},
			homeTo:function(){
				var that=this;
				uni.showModal({
					title: '微信授权',
					content: '获得你的公开信息（昵称、头像、地区及性别）',
					confirmText:'允许',
					cancelText:'拒绝',
					confirmColor:'green',
					 success: function (res) {
					if (res.confirm) {
						uni.switchTab({
							url: '/pages/home/home'
						});
						that.activeDisplay="none",
						that.anotherDisplay='block'
					} else if (res.cancel) {
						console.log('用户点击取消');
					}
    }
				});
			}
		}
	}
</script>

<style>
	.empower-body{
		height: 200upx;
		width: 80%;
		float: left;
		margin: 100upx 10% 10upx;
	}
	.empower-img{
		width: 150upx;
		height: 150upx;
		border-radius: 100upx;
		float: left;
		border: 1px solid #999999;
		float: left;
		margin: 150upx 300upx 0upx;
	}
	.empower-top{
		float: left;
		width: 100%;
		height: 350upx;
	}
		
</style>
