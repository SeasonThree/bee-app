<script>
	export default {
		onLaunch: function () {
			console.log('App Launch')
		},
		onShow: function () {
			console.log('App Show')
		},
		onHide: function () {
			console.log('App Hide')
		},
			
		gloabalData:{
			
		}
	}
</script>

<style>
	@font-face {
  font-family: 'iconfont';  /* project id 1032776 */
  src: url('https://at.alicdn.com/t/font_1032776_7w3zsppcdfy.eot');
  src: url('https://at.alicdn.com/t/font_1032776_7w3zsppcdfy.eot?#iefix') format('embedded-opentype'),
  url('https://at.alicdn.com/t/font_1032776_7w3zsppcdfy.woff2') format('woff2'),
  url('https://at.alicdn.com/t/font_1032776_7w3zsppcdfy.woff') format('woff'),
  url('https://at.alicdn.com/t/font_1032776_7w3zsppcdfy.ttf') format('truetype'),
  url('https://at.alicdn.com/t/font_1032776_7w3zsppcdfy.svg#iconfont') format('svg');
}
	.iconfont {
  font-family: "iconfont" !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
	.all-content{
		float: left;
		margin-top: 40upx;
		width: 100%;
		height: 600upx;
		background: white;
	}
	.blue-top{
		height: 150upx;
		width: 100%;
		background: #21B0FF;
		text-align: center;
}
	.all-img{
		width: 90upx;
		height: 90upx;
		margin:30upx;
	}
	.all-search{
	  height: 70rpx;
	  width: 700rpx;
	  margin: auto;
	}
	.all-search .icon-sousuo{
	  position: relative;
	  left: 290rpx;
	  top: -68rpx;
	  z-index: 1;
	  color: grey;
	}
	.all-seach1{
	  z-index: 0;
	  height: 70rpx;
	  width: 700rpx;
	  background-color: white;
	  margin:auto;
	  position: relative;
	  top: 10rpx;
	  font-size:25rpx; 
	  border-radius: 40rpx;
	  text-align: center;
	}
	.padding-sm{
	  padding: 10upx;
	}
	.padding-md{
	  padding: 20upx;
	}
	.padding-lg{
	  padding: 10upx 40upx;
	}
	.font-xs{
	  font-size: 24upx;
	}
	.font-sm{
	  font-size:30upx;
	}
	.font-md{
	  font-size:40upx;
	}
	.font-lg{
	  font-size:50upx;
	}
	.font-xl{
	  font-size:80upx;
	}
	.container{
	  background-color:#F5F6F8;
	
	  
	  /* display: flex;
	  flex-direction: column; */
	 /* justify-content: space-around; */
	  align-items: center; 
	  /*use flexible box to set style from the global aspect*/
	font-size: 32upx;
	width: 750upx;
	min-height: 1207upx;
	}
</style>
